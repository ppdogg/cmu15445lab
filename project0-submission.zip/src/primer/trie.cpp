#include "primer/trie.h"
#include <string_view>
#include "common/exception.h"

namespace bustub {

// You should walk through the trie to find the node corresponding to the key. If the node doesn't exist, return
// nullptr. After you find the node, you should use `dynamic_cast` to cast it to `const TrieNodeWithValue<T> *`. If
// dynamic_cast returns `nullptr`, it means the type of the value is mismatched, and you should return nullptr.
// Otherwise, return the value.
template <class T>
auto Trie::Get(std::string_view key) const -> const T * {
  if (this->root_ == nullptr) {
    return nullptr;
  }

  auto cur_ptr = this->root_;
  for (char i : key) {
    if (cur_ptr->children_.find(i) != cur_ptr->children_.end()) {
      cur_ptr = cur_ptr->children_.at(i);
    } else {
      // match failed
      return nullptr;
    }
  }

  // match succeed
  if (cur_ptr->is_value_node_) {
    const auto *new_ptr = dynamic_cast<const TrieNodeWithValue<T> *>(cur_ptr.get());
    if (new_ptr == nullptr) {
      return nullptr;
    }
    return new_ptr->value_.get();
  }

  return nullptr;
}

template <class T>
auto Trie::Put(std::string_view key, T value) const -> Trie {
  // Note that `T` might be a non-copyable type. Always use `std::move` when creating `shared_ptr` on that value.
  auto with_value = [&value](std::shared_ptr<const TrieNode> const &ptr) -> std::shared_ptr<TrieNodeWithValue<T>> {
    auto children = ptr ? ptr->children_ : decltype(ptr->children_){};
    auto node = TrieNodeWithValue<T>(std::move(children), std::make_shared<T>(std::move(value)));
    return std::make_shared<TrieNodeWithValue<T>>(std::move(node));
  };

  auto clone_or_create = [](std::shared_ptr<const TrieNode> const &ptr) -> std::shared_ptr<TrieNode> {
    if (ptr == nullptr) {
      return std::make_shared<TrieNode>(std::map<char, std::shared_ptr<const TrieNode>>());
    }
    auto clone_ptr = ptr->Clone();
    return std::shared_ptr<TrieNode>{std::move(clone_ptr)};
  };

  if (key.empty()) {
    return Trie(with_value(this->root_));
  }

  // create new root node
  auto new_root = clone_or_create(this->root_);

  auto cur_ptr = new_root.get();
  // iterate over key
  for (std::string_view::size_type i = 0; i < key.length() - 1; i++) {
    auto temp_ptr = clone_or_create(cur_ptr->children_[key[i]]);
    auto next = temp_ptr.get();
    cur_ptr->children_[key[i]] = std::move(temp_ptr);
    cur_ptr = next;
  }
  // key already exists, change value
  cur_ptr->children_[key.back()] = with_value(cur_ptr->children_[key.back()]);

  return Trie(std::move(new_root));
  // You should walk through the trie and create new nodes if necessary. If the node corresponding to the key already
  // exists, you should create a new `TrieNodeWithValue`.
}

auto Trie::Remove(std::string_view key) const -> Trie {
  if (this->root_ == nullptr) {
    return *this;
  }

  // create new root
  auto clone_ptr = this->root_->Clone();
  auto new_root = std::shared_ptr<TrieNode>(std::move(clone_ptr));

  auto header = new_root.get();
  auto cur_ptr = this->root_;
  for (std::string_view::size_type i = 0; i < key.length(); i++) {
    if (cur_ptr->children_.find(key[i]) != cur_ptr->children_.end()) {
      cur_ptr = cur_ptr->children_.at(key[i]);

      if (i == key.length() - 1) {
        // key exists
        break;
      }
      // clone node for new trie
      auto clone_ptr = cur_ptr->Clone();
      auto temp_ptr = std::shared_ptr<TrieNode>(std::move(clone_ptr));
      auto next = temp_ptr.get();
      header->children_[key[i]] = std::move(temp_ptr);
      header = next;
    } else {
      // key not exists
      return *this;
    }
  }

  if (cur_ptr->children_.empty()) {
    // have no children, remove node
    header->children_.erase(key.back());
  } else {
    // remove value
    auto new_ptr = std::make_shared<const TrieNode>(TrieNode(cur_ptr->children_));
    header->children_[key.back()] = std::move(new_ptr);
  }

  return Trie(std::move(new_root));
  // You should walk through the trie and remove nodes if necessary. If the node doesn't contain a value any more,
  // you should convert it to `TrieNode`. If a node doesn't have children any more, you should remove it.
}

// Below are explicit instantiation of template functions.
//
// Generally people would write the implementation of template classes and functions in the header file. However, we
// separate the implementation into a .cpp file to make things clearer. In order to make the compiler know the
// implementation of the template functions, we need to explicitly instantiate them here, so that they can be picked up
// by the linker.

template auto Trie::Put(std::string_view key, uint32_t value) const -> Trie;
template auto Trie::Get(std::string_view key) const -> const uint32_t *;

template auto Trie::Put(std::string_view key, uint64_t value) const -> Trie;
template auto Trie::Get(std::string_view key) const -> const uint64_t *;

template auto Trie::Put(std::string_view key, std::string value) const -> Trie;
template auto Trie::Get(std::string_view key) const -> const std::string *;

// If your solution cannot compile for non-copy tests, you can remove the below lines to get partial score.

using Integer = std::unique_ptr<uint32_t>;

template auto Trie::Put(std::string_view key, Integer value) const -> Trie;
template auto Trie::Get(std::string_view key) const -> const Integer *;

template auto Trie::Put(std::string_view key, MoveBlocked value) const -> Trie;
template auto Trie::Get(std::string_view key) const -> const MoveBlocked *;

}  // namespace bustub
