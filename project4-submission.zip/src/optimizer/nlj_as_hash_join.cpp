#include <algorithm>
#include <memory>
#include <vector>
#include "binder/bound_expression.h"
#include "catalog/column.h"
#include "catalog/schema.h"
#include "common/exception.h"
#include "common/macros.h"
#include "execution/expressions/abstract_expression.h"
#include "execution/expressions/column_value_expression.h"
#include "execution/expressions/comparison_expression.h"
#include "execution/expressions/constant_value_expression.h"
#include "execution/expressions/logic_expression.h"
#include "execution/plans/abstract_plan.h"
#include "execution/plans/filter_plan.h"
#include "execution/plans/hash_join_plan.h"
#include "execution/plans/nested_loop_join_plan.h"
#include "execution/plans/projection_plan.h"
#include "execution/plans/seq_scan_plan.h"
#include "optimizer/optimizer.h"
#include "type/type_id.h"

namespace bustub {

void ParseCmpExpression(const ComparisonExpression *cmp_expr, std::vector<AbstractExpressionRef> &left,
                        std::vector<AbstractExpressionRef> &right) {
  auto const &left_expr = cmp_expr->GetChildren()[0];
  const auto *left_column_expr = dynamic_cast<ColumnValueExpression *>(left_expr.get());
  if (left_column_expr == nullptr) {
    return;
  }

  auto const &right_expr = cmp_expr->GetChildren()[1];
  const auto *right_column_expr = dynamic_cast<ColumnValueExpression *>(right_expr.get());
  if (right_column_expr == nullptr) {
    return;
  }

  auto left_table_index = left_column_expr->GetTupleIdx();
  auto right_table_index = right_column_expr->GetTupleIdx();
  if (left_table_index == 1 && right_table_index == 0) {
    left.emplace_back(right_expr);
    right.emplace_back(left_expr);
  } else if (left_table_index == 0 && right_table_index == 1) {
    left.emplace_back(left_expr);
    right.emplace_back(right_expr);
  }
}

auto Optimizer::OptimizeNLJAsHashJoin(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef {
  // TODO(student): implement NestedLoopJoin -> HashJoin optimizer rule
  // Note for 2023 Spring: You should at least support join keys of the form:

  std::vector<AbstractPlanNodeRef> children;
  for (const auto &child : plan->GetChildren()) {
    children.emplace_back(OptimizeNLJAsHashJoin(child));
  }
  auto optimized_plan = plan->CloneWithChildren(std::move(children));
  if (optimized_plan->GetType() == PlanType::NestedLoopJoin) {
    const auto &nested_loop_join_plan = dynamic_cast<NestedLoopJoinPlanNode &>(*optimized_plan);
    const auto &predict = nested_loop_join_plan.Predicate();

    // 1. <column expr> = <column expr>
    const auto *cmp_expr = dynamic_cast<ComparisonExpression *>(predict.get());
    if (cmp_expr != nullptr) {
      std::vector<AbstractExpressionRef> left_expr{};
      std::vector<AbstractExpressionRef> right_expr{};
      bustub::ParseCmpExpression(cmp_expr, left_expr, right_expr);
      return std::make_shared<HashJoinPlanNode>(
          std::make_shared<const Schema>(optimized_plan->OutputSchema()), nested_loop_join_plan.GetLeftPlan(),
          nested_loop_join_plan.GetRightPlan(), left_expr, right_expr, nested_loop_join_plan.GetJoinType());
    }

    // 2. <column expr> = <column expr> AND <column expr> = <column expr>
    const auto *logic_expr = dynamic_cast<LogicExpression *>(predict.get());
    if (logic_expr != nullptr) {
      auto const &left_child_expr = logic_expr->GetChildren()[0];
      const auto *left_cmp_expr = dynamic_cast<ComparisonExpression *>(left_child_expr.get());

      auto const &right_child_expr = logic_expr->GetChildren()[1];
      const auto *right_cmp_expr = dynamic_cast<ComparisonExpression *>(right_child_expr.get());

      std::vector<AbstractExpressionRef> left_exprs{};
      std::vector<AbstractExpressionRef> right_exprs{};

      bustub::ParseCmpExpression(left_cmp_expr, left_exprs, right_exprs);
      bustub::ParseCmpExpression(right_cmp_expr, left_exprs, right_exprs);

      return std::make_shared<HashJoinPlanNode>(
          std::make_shared<const Schema>(optimized_plan->OutputSchema()), nested_loop_join_plan.GetLeftPlan(),
          nested_loop_join_plan.GetRightPlan(), left_exprs, right_exprs, nested_loop_join_plan.GetJoinType());
    }
  }
  return optimized_plan;
}

}  // namespace bustub
