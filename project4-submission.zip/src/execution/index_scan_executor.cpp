//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// index_scan_executor.cpp
//
// Identification: src/execution/index_scan_executor.cpp
//
// Copyright (c) 2015-19, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include "execution/executors/index_scan_executor.h"
#include <memory>
#include <utility>
#include "storage/table/tuple.h"

namespace bustub {
IndexScanExecutor::IndexScanExecutor(ExecutorContext *exec_ctx, const IndexScanPlanNode *plan)
    : AbstractExecutor(exec_ctx), plan_(plan) {}

void IndexScanExecutor::Init() {
  this->index_info_ = this->GetExecutorContext()->GetCatalog()->GetIndex(this->plan_->GetIndexOid());
  this->cur_table_ = this->GetExecutorContext()->GetCatalog()->GetTable(index_info_->table_name_);
  this->tree_ = dynamic_cast<BPlusTreeIndexForTwoIntegerColumn *>(index_info_->index_.get());
  this->tree_iter_ = std::make_unique<BPlusTreeIndexIteratorForTwoIntegerColumn>(this->tree_->GetBeginIterator());
}

auto IndexScanExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (tree_iter_->IsEnd()) {
    return false;
  }

  std::pair<TupleMeta, Tuple> res;
  do {
    auto cur_value = **tree_iter_;
    *rid = cur_value.second;
    res = this->cur_table_->table_->GetTuple(*rid);
    *tuple = res.second;
    ++(*tree_iter_);
  } while (!tree_iter_->IsEnd() && res.first.is_deleted_);

  return !res.first.is_deleted_;
}

}  // namespace bustub
