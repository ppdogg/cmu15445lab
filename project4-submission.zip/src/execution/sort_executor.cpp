#include "execution/executors/sort_executor.h"
#include <algorithm>
#include <utility>
#include <vector>
#include "binder/bound_order_by.h"
#include "storage/table/tuple.h"

namespace bustub {

SortExecutor::SortExecutor(ExecutorContext *exec_ctx, const SortPlanNode *plan,
                           std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void SortExecutor::Init() {
  child_executor_->Init();
  tuples_.clear();
  cursor_ = 0;

  Tuple tuple{};
  RID rid{};
  auto status = child_executor_->Next(&tuple, &rid);
  while (status) {
    tuples_.emplace_back(tuple);
    status = child_executor_->Next(&tuple, &rid);
  }

  auto asc = [&](const Tuple &l, const Tuple &r) -> bool {
    for (const auto &order : this->plan_->GetOrderBy()) {
      auto lv = order.second->Evaluate(&l, child_executor_->GetOutputSchema());
      auto rv = order.second->Evaluate(&r, child_executor_->GetOutputSchema());
      if (order.first == OrderByType::DESC) {
        if (lv.CompareGreaterThan(rv) == CmpBool::CmpTrue) {
          return true;
        }
        if (lv.CompareLessThan(rv) == CmpBool::CmpTrue) {
          return false;
        }
      } else {
        if (lv.CompareLessThan(rv) == CmpBool::CmpTrue) {
          return true;
        }
        if (lv.CompareGreaterThan(rv) == CmpBool::CmpTrue) {
          return false;
        }
      }
    }
    return false;
  };

  std::sort(tuples_.begin(), tuples_.end(), asc);
}

auto SortExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (this->cursor_ >= this->tuples_.size()) {
    return false;
  }
  *tuple = this->tuples_[this->cursor_];
  this->cursor_++;
  return true;
}

}  // namespace bustub
