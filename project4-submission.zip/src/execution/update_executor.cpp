//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// update_executor.cpp
//
// Identification: src/execution/update_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include <memory>
#include <utility>

#include "execution/executors/update_executor.h"

namespace bustub {

UpdateExecutor::UpdateExecutor(ExecutorContext *exec_ctx, const UpdatePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {
  // As of Fall 2022, you DON'T need to implement update executor to have perfect score in project 3 / project 4.
  this->table_info_ = this->GetExecutorContext()->GetCatalog()->GetTable(plan->TableOid());
  this->index_infos_ = this->GetExecutorContext()->GetCatalog()->GetTableIndexes(this->table_info_->name_);
}

void UpdateExecutor::Init() { this->child_executor_->Init(); }

auto UpdateExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
  if (is_end_) {
    return false;
  }
  auto txn = this->GetExecutorContext()->GetTransaction();
  int res = 0;
  auto status = child_executor_->Next(tuple, rid);
  auto index_info = this->exec_ctx_->GetCatalog()->GetTableIndexes(this->table_info_->name_);
  while (status) {
    // Compute expressions
    std::vector<Value> values{};
    values.reserve(GetOutputSchema().GetColumnCount());
    for (const auto &expr : this->plan_->target_expressions_) {
      values.push_back(expr->Evaluate(tuple, child_executor_->GetOutputSchema()));
    }
    auto new_tuple = Tuple{values, &child_executor_->GetOutputSchema()};

    this->table_info_->table_->UpdateTupleMeta({INVALID_TXN_ID, txn->GetTransactionId(), true}, *rid);
    for (auto info : index_info) {
      auto key = tuple->KeyFromTuple(this->table_info_->schema_, info->key_schema_, info->index_->GetKeyAttrs());
      info->index_->DeleteEntry(key, *rid, txn);
    }

    auto new_rid = this->table_info_->table_
                       ->InsertTuple({txn->GetTransactionId(), INVALID_TXN_ID, false}, new_tuple,
                                     this->exec_ctx_->GetLockManager(), txn, this->plan_->TableOid())
                       .value();
    for (auto info : index_info) {
      auto key = new_tuple.KeyFromTuple(this->table_info_->schema_, info->key_schema_, info->index_->GetKeyAttrs());
      info->index_->InsertEntry(key, new_rid, txn);
    }

    status = child_executor_->Next(tuple, rid);
    res++;
  }
  std::vector<Value> values;
  values.reserve(GetOutputSchema().GetColumnCount());
  values.emplace_back(INTEGER, res);
  *tuple = Tuple(values, &GetOutputSchema());
  is_end_ = true;
  return true;
}

}  // namespace bustub
