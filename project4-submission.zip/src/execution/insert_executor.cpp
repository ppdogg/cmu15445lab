//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// insert_executor.cpp
//
// Identification: src/execution/insert_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/insert_executor.h"

#include "common/config.h"
#include "common/exception.h"
#include "common/rid.h"
#include "concurrency/lock_manager.h"
#include "concurrency/transaction.h"

namespace bustub {

InsertExecutor::InsertExecutor(ExecutorContext *exec_ctx, const InsertPlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void InsertExecutor::Init() {
  child_executor_->Init();
  auto txn = this->GetExecutorContext()->GetTransaction();
  try {
    if (!this->GetExecutorContext()->GetLockManager()->LockTable(txn, LockManager::LockMode::INTENTION_EXCLUSIVE,
                                                                 this->plan_->TableOid())) {
      throw ExecutionException("lock table failed");
    }
  } catch (TransactionAbortException) {
    throw ExecutionException("lock table failed: transaction abort");
  }
  this->cur_table_ = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->TableOid());
  this->index_infos_ = this->GetExecutorContext()->GetCatalog()->GetTableIndexes(this->cur_table_->name_);
}

auto InsertExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (is_end_) {
    return false;
  }
  auto txn = this->GetExecutorContext()->GetTransaction();
  int res = 0;
  auto status = child_executor_->Next(tuple, rid);
  while (status) {
    auto insert_result = this->cur_table_->table_->InsertTuple({txn->GetTransactionId(), INVALID_TXN_ID, false}, *tuple,
                                                               this->GetExecutorContext()->GetLockManager(), txn,
                                                               this->cur_table_->oid_);
    if (insert_result.has_value()) {
      try {
        if (!this->GetExecutorContext()->GetLockManager()->LockRow(txn, LockManager::LockMode::EXCLUSIVE,
                                                                   cur_table_->oid_, *insert_result)) {
          throw ExecutionException("insert lock row failed");
        }
      } catch (TransactionAbortException) {
        throw ExecutionException("insert lock row failed: transcation abort");
      }
      auto iwr = TableWriteRecord(cur_table_->oid_, *insert_result, cur_table_->table_.get());
      iwr.wtype_ = WType::INSERT;
      txn->GetWriteSet()->emplace_back(iwr);
      for (auto index_info : this->index_infos_) {
        txn->GetIndexWriteSet()->emplace_back(IndexWriteRecord(*insert_result, cur_table_->oid_, WType::INSERT, *tuple,
                                                               index_info->index_oid_,
                                                               this->GetExecutorContext()->GetCatalog()));
        auto key = tuple->KeyFromTuple(cur_table_->schema_, index_info->key_schema_, index_info->index_->GetKeyAttrs());
        index_info->index_->InsertEntry(key, *insert_result, txn);
      }
      res++;
    }
    status = child_executor_->Next(tuple, rid);
  }
  std::vector<Value> values;
  values.reserve(GetOutputSchema().GetColumnCount());
  values.emplace_back(INTEGER, res);
  *tuple = Tuple(values, &GetOutputSchema());
  is_end_ = true;
  return true;
}

}  // namespace bustub
