//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// aggregation_executor.cpp
//
// Identification: src/execution/aggregation_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include <algorithm>
#include <cstddef>
#include <iostream>
#include <memory>
#include <ostream>
#include <utility>
#include <vector>

#include "execution/executors/aggregation_executor.h"
#include "execution/plans/aggregation_plan.h"
#include "storage/table/tuple.h"
#include "type/type_id.h"
#include "type/value.h"
#include "type/value_factory.h"

namespace bustub {

AggregationExecutor::AggregationExecutor(ExecutorContext *exec_ctx, const AggregationPlanNode *plan,
                                         std::unique_ptr<AbstractExecutor> &&child)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      child_(std::move(child)),
      aht_(SimpleAggregationHashTable(this->plan_->GetAggregates(), this->plan_->GetAggregateTypes())),
      aht_iterator_(this->aht_.Begin()) {}

void AggregationExecutor::Init() {
  child_->Init();
  this->aht_.Clear();

  Tuple tuple{};
  RID rid{};
  auto status = child_->Next(&tuple, &rid);
  if (!status) {
    if (tuple.GetLength() != 0) {
      this->aht_.InsertCombine(this->MakeAggregateKey(&tuple), AggregateValue{std::vector<Value>{}});
    }
    this->aht_iterator_ = this->aht_.Begin();
    return;
  }
  while (status) {
    AggregateKey key;
    if (!this->plan_->GetGroupBys().empty()) {
      std::vector<Value> vals;
      for (const auto &g : this->plan_->GetGroupBys()) {
        vals.emplace_back(g->Evaluate(&tuple, child_->GetOutputSchema()));
      }
      key = AggregateKey{vals};
    } else {
      key = this->MakeAggregateKey(&tuple);
    }
    auto val = this->MakeAggregateValue(&tuple);
    this->aht_.InsertCombine(key, val);
    status = child_->Next(&tuple, &rid);
  }
  this->aht_iterator_ = this->aht_.Begin();
}

auto AggregationExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (this->aht_iterator_ == this->aht_.End()) {
    return false;
  }
  if (!this->plan_->GetGroupBys().empty()) {
    std::vector<Value> res;
    for (const auto &k : this->aht_iterator_.Key().group_bys_) {
      res.emplace_back(k);
    }
    for (const auto &k : this->aht_iterator_.Val().aggregates_) {
      res.emplace_back(k);
    }
    *tuple = Tuple(res, &this->GetOutputSchema());
  } else {
    *tuple = Tuple(this->aht_iterator_.Val().aggregates_, &this->GetOutputSchema());
  }
  ++this->aht_iterator_;
  return true;
}

auto AggregationExecutor::GetChildExecutor() const -> const AbstractExecutor * { return child_.get(); }

}  // namespace bustub
