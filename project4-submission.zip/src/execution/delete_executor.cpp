//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// delete_executor.cpp
//
// Identification: src/execution/delete_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/delete_executor.h"

#include "concurrency/transaction.h"

namespace bustub {

DeleteExecutor::DeleteExecutor(ExecutorContext *exec_ctx, const DeletePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void DeleteExecutor::Init() {
  child_executor_->Init();
  this->cur_table_ = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->TableOid());
  this->index_infos_ = this->GetExecutorContext()->GetCatalog()->GetTableIndexes(this->cur_table_->name_);
}

auto DeleteExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (is_end_) {
    return false;
  }
  auto txn = this->GetExecutorContext()->GetTransaction();
  int res = 0;
  auto status = child_executor_->Next(tuple, rid);
  while (status) {
    this->cur_table_->table_->UpdateTupleMeta(TupleMeta{INVALID_TXN_ID, txn->GetTransactionId(), true}, *rid);
    auto iwr = TableWriteRecord(cur_table_->oid_, *rid, cur_table_->table_.get());
    iwr.wtype_ = WType::DELETE;
    txn->GetWriteSet()->emplace_back(iwr);
    for (auto index_info : this->index_infos_) {
      txn->GetIndexWriteSet()->emplace_back(IndexWriteRecord(*rid, cur_table_->oid_, WType::INSERT, *tuple,
                                                             index_info->index_oid_,
                                                             this->GetExecutorContext()->GetCatalog()));
      auto key =
          tuple->KeyFromTuple(this->cur_table_->schema_, index_info->key_schema_, index_info->index_->GetKeyAttrs());
      index_info->index_->DeleteEntry(key, *rid, txn);
    }
    status = child_executor_->Next(tuple, rid);
    res++;
  }
  std::vector<Value> values;
  values.reserve(GetOutputSchema().GetColumnCount());
  values.emplace_back(INTEGER, res);
  *tuple = Tuple(values, &GetOutputSchema());
  is_end_ = true;
  return true;
}

}  // namespace bustub
