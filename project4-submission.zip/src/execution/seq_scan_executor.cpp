//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// seq_scan_executor.cpp
//
// Identification: src/execution/seq_scan_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/seq_scan_executor.h"
#include <iostream>
#include <ostream>

#include "common/exception.h"
#include "common/rid.h"
#include "concurrency/lock_manager.h"
#include "concurrency/transaction.h"
#include "storage/table/table_iterator.h"

namespace bustub {

SeqScanExecutor::SeqScanExecutor(ExecutorContext *exec_ctx, const SeqScanPlanNode *plan)
    : AbstractExecutor(exec_ctx), plan_(plan) {}

void SeqScanExecutor::Init() {
  this->row_share_locked_.clear();

  auto txn = this->GetExecutorContext()->GetTransaction();
  if (this->GetExecutorContext()->IsDelete()) {
    try {
      if (!this->GetExecutorContext()->GetLockManager()->LockTable(txn, LockManager::LockMode::INTENTION_EXCLUSIVE,
                                                                   this->plan_->GetTableOid())) {
        throw ExecutionException("seqscan lock table failed");
      }
    } catch (TransactionAbortException) {
      throw ExecutionException("seqscan lock table failed: transaction aborted");
    }
  } else {
    switch (txn->GetIsolationLevel()) {
      case IsolationLevel::REPEATABLE_READ:
      case IsolationLevel::READ_COMMITTED:
        if (txn->GetExclusiveTableLockSet()->count(this->plan_->GetTableOid()) == 0 &&
            txn->GetIntentionExclusiveTableLockSet()->count(this->plan_->GetTableOid()) == 0) {
          try {
            if (!this->GetExecutorContext()->GetLockManager()->LockTable(txn, LockManager::LockMode::INTENTION_SHARED,
                                                                         this->plan_->GetTableOid())) {
              throw ExecutionException("seqscan lock table failed");
            }
          } catch (TransactionAbortException) {
            throw ExecutionException("seqscan lock table failed: transaction aborted");
          }
        }
        break;
      case IsolationLevel::READ_UNCOMMITTED:
        break;
    }
  }

  this->cur_table_ = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
  this->cur_table_iter_ = std::make_unique<TableIterator>(this->cur_table_->table_->MakeEagerIterator());
}

auto SeqScanExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  auto txn = this->GetExecutorContext()->GetTransaction();
  std::pair<TupleMeta, Tuple> tuple_pair;
  do {
    if (this->cur_table_iter_->IsEnd()) {
      if (!this->GetExecutorContext()->IsDelete() && txn->GetIsolationLevel() == IsolationLevel::READ_COMMITTED) {
        for (const auto &r : this->row_share_locked_) {
          this->GetExecutorContext()->GetLockManager()->UnlockRow(txn, cur_table_->oid_, r);
        }
      }
      return false;
    }

    tuple_pair = this->cur_table_iter_->GetTuple();
    *rid = this->cur_table_iter_->GetRID();

    if (!tuple_pair.first.is_deleted_) {
      if (this->GetExecutorContext()->IsDelete()) {
        try {
          if (!this->GetExecutorContext()->GetLockManager()->LockRow(txn, LockManager::LockMode::EXCLUSIVE,
                                                                     cur_table_->oid_, *rid)) {
            throw ExecutionException("seqscan lock row failed");
          }
        } catch (TransactionAbortException) {
          throw ExecutionException("seqscan lock row failed: transaction aborted");
        }
      } else {
        switch (txn->GetIsolationLevel()) {
          case IsolationLevel::REPEATABLE_READ:
            try {
              if (!this->GetExecutorContext()->GetLockManager()->LockRow(txn, LockManager::LockMode::SHARED,
                                                                         cur_table_->oid_, *rid)) {
                throw ExecutionException("seqscan lock row failed");
              }
            } catch (TransactionAbortException) {
              throw ExecutionException("seqscan lock row failed: transaction aborted");
            }
            break;
          case IsolationLevel::READ_COMMITTED:
            if (txn->GetExclusiveRowLockSet()->count(cur_table_->oid_) == 0 ||
                txn->GetExclusiveRowLockSet()->at(cur_table_->oid_).count(*rid) == 0) {
              try {
                if (!this->GetExecutorContext()->GetLockManager()->LockRow(txn, LockManager::LockMode::SHARED,
                                                                           cur_table_->oid_, *rid)) {
                  throw ExecutionException("seqscan lock row failed");
                }
                this->row_share_locked_.emplace_back(*rid);
              } catch (TransactionAbortException) {
                throw ExecutionException("seqscan lock row failed: transaction aborted");
              }
            }
            break;
          case IsolationLevel::READ_UNCOMMITTED:
            break;
        }
      }
    }

    tuple_pair = this->cur_table_iter_->GetTuple();
    *tuple = tuple_pair.second;
    ++(*this->cur_table_iter_);
  } while (tuple_pair.first.is_deleted_);

  return true;
}

}  // namespace bustub
