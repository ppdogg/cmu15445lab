/**
 * index_iterator.cpp
 */
#include <cassert>
#include <utility>

#include "storage/index/index_iterator.h"
#include "storage/page/b_plus_tree_leaf_page.h"
#include "storage/page/page_guard.h"

namespace bustub {

/*
 * NOTE: you can change the destructor/constructor method here
 * set your own input parameters
 */
INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator(BufferPoolManager *bpm, page_id_t page_id, int cur_index)
    : cur_page_id_(page_id), cur_index_(cur_index), bpm_(bpm) {}

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::~IndexIterator() {}  // NOLINT

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::IsEnd() -> bool { return this->cur_page_id_ == INVALID_PAGE_ID; }

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator*() -> const MappingType & {
  ReadPageGuard read_guard = this->bpm_->FetchPageRead(this->cur_page_id_);
  auto p = read_guard.As<BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>>();
  return p->GetValue(this->cur_index_);
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator++() -> INDEXITERATOR_TYPE & {
  ReadPageGuard read_guard = this->bpm_->FetchPageRead(this->cur_page_id_);
  auto p = read_guard.As<BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>>();

  if (this->cur_index_ < p->GetSize() - 1) {
    this->cur_index_++;
  } else {
    this->cur_page_id_ = p->GetNextPageId();
    this->cur_index_ = this->cur_page_id_ == INVALID_PAGE_ID ? -1 : 0;
  }

  return *this;
}

template class IndexIterator<GenericKey<4>, RID, GenericComparator<4>>;

template class IndexIterator<GenericKey<8>, RID, GenericComparator<8>>;

template class IndexIterator<GenericKey<16>, RID, GenericComparator<16>>;

template class IndexIterator<GenericKey<32>, RID, GenericComparator<32>>;

template class IndexIterator<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
