//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lock_manager.cpp
//
// Identification: src/concurrency/lock_manager.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "concurrency/lock_manager.h"

#include "common/config.h"
#include "common/exception.h"
#include "common/rid.h"
#include "concurrency/transaction.h"
#include "concurrency/transaction_manager.h"

namespace bustub {

auto LockManager::GrantLock(LockRequestQueue *lock_request_queue, LockRequest *lock_request) -> bool {
  // current lock request should be compatible with granted lock request
  for (const auto &lr : lock_request_queue->request_queue_) {
    if (lr->granted_) {
      if (!this->AreLocksCompatible(lr->lock_mode_, lock_request->lock_mode_)) {
        return false;
      }
    }
  }
  // current lock request is upgrading
  if (lock_request_queue->upgrading_ == lock_request->txn_id_) {
    return true;
  }
  // there other upgrading lock request
  if (lock_request_queue->upgrading_ != INVALID_TXN_ID) {
    return false;
  }

  for (const auto &lr : lock_request_queue->request_queue_) {
    // locks should be granted to transactions in a FIFO manner.
    if (lr->txn_id_ == lock_request->txn_id_) {
      return true;
    }
    // If there are multiple compatible lock requests, all should be granted at the same time
    // as long as FIFO is honoured.
    if (!this->AreLocksCompatible(lr->lock_mode_, lock_request->lock_mode_)) {
      return false;
    }
  }
  return true;
}

void LockManager::UnlockRequestQueue(Transaction *txn, LockRequest *lock_request) {
  switch (txn->GetIsolationLevel()) {
    case IsolationLevel::READ_UNCOMMITTED:
    case IsolationLevel::READ_COMMITTED: {
      switch (lock_request->lock_mode_) {
        case LockMode::EXCLUSIVE:
          txn->SetState(TransactionState::SHRINKING);
          break;
        case LockMode::SHARED:
        case LockMode::INTENTION_SHARED:
        case LockMode::INTENTION_EXCLUSIVE:
        case LockMode::SHARED_INTENTION_EXCLUSIVE:
          break;
      }
    } break;
    case IsolationLevel::REPEATABLE_READ: {
      switch (lock_request->lock_mode_) {
        case LockMode::SHARED:
        case LockMode::EXCLUSIVE:
          txn->SetState(TransactionState::SHRINKING);
          break;
        case LockMode::INTENTION_SHARED:
        case LockMode::INTENTION_EXCLUSIVE:
        case LockMode::SHARED_INTENTION_EXCLUSIVE:
          break;
      }
    } break;
  }
}

void LockManager::BookkeepInsertTable(Transaction *txn, LockMode lock_mode, const table_oid_t &oid) {
  switch (lock_mode) {
    case LockMode::SHARED:
      txn->GetSharedTableLockSet()->insert(oid);
      break;
    case LockMode::EXCLUSIVE:
      txn->GetExclusiveTableLockSet()->insert(oid);
      break;
    case LockMode::INTENTION_SHARED:
      txn->GetIntentionSharedTableLockSet()->insert(oid);
      break;
    case LockMode::INTENTION_EXCLUSIVE:
      txn->GetIntentionExclusiveTableLockSet()->insert(oid);
      break;
    case LockMode::SHARED_INTENTION_EXCLUSIVE:
      txn->GetSharedIntentionExclusiveTableLockSet()->insert(oid);
      break;
  }
}

void LockManager::BookkeepRemoveTable(Transaction *txn, LockMode lock_mode, const table_oid_t &oid) {
  switch (lock_mode) {
    case LockMode::SHARED:
      txn->GetSharedTableLockSet()->erase(oid);
      break;
    case LockMode::EXCLUSIVE:
      txn->GetExclusiveTableLockSet()->erase(oid);
      break;
    case LockMode::INTENTION_SHARED:
      txn->GetIntentionSharedTableLockSet()->erase(oid);
      break;
    case LockMode::INTENTION_EXCLUSIVE:
      txn->GetIntentionExclusiveTableLockSet()->erase(oid);
      break;
    case LockMode::SHARED_INTENTION_EXCLUSIVE:
      txn->GetSharedIntentionExclusiveTableLockSet()->erase(oid);
      break;
  }
}

void LockManager::BookkeepInsertRow(Transaction *txn, LockMode lock_mode, const table_oid_t &oid, const RID &rid) {
  switch (lock_mode) {
    case LockMode::SHARED:
      (*txn->GetSharedRowLockSet())[oid].insert(rid);
      break;
    case LockMode::EXCLUSIVE:
      (*txn->GetExclusiveRowLockSet())[oid].insert(rid);
      break;
    case LockMode::INTENTION_SHARED:
    case LockMode::INTENTION_EXCLUSIVE:
    case LockMode::SHARED_INTENTION_EXCLUSIVE:
      break;
  }
}

void LockManager::BookkeepRemoveRow(Transaction *txn, LockMode lock_mode, const table_oid_t &oid, const RID &rid) {
  switch (lock_mode) {
    case LockMode::SHARED:
      txn->GetSharedRowLockSet()->at(oid).erase(rid);
      break;
    case LockMode::EXCLUSIVE:
      txn->GetExclusiveRowLockSet()->at(oid).erase(rid);
      break;
    case LockMode::INTENTION_SHARED:
    case LockMode::INTENTION_EXCLUSIVE:
    case LockMode::SHARED_INTENTION_EXCLUSIVE:
      break;
  }
}

auto LockManager::CanTxnTakeLock(Transaction *txn, LockMode lock_mode) -> bool {
  switch (txn->GetIsolationLevel()) {
    case IsolationLevel::READ_UNCOMMITTED: {
      // S, IS, SIX locks are never allowed
      if (lock_mode != LockMode::EXCLUSIVE && lock_mode != LockMode::INTENTION_EXCLUSIVE) {
        // set the TransactionState as ABORTED and throw a TransactionAbortException (LOCK_SHARED_ON_READ_UNCOMMITTED).
        txn->SetState(TransactionState::ABORTED);
        throw TransactionAbortException(txn->GetTransactionId(), AbortReason::LOCK_SHARED_ON_READ_UNCOMMITTED);
      }
      switch (txn->GetState()) {
        case TransactionState::GROWING:
          // X, IX locks are allowed in the GROWING state.
          return true;
        case TransactionState::SHRINKING: {
          txn->SetState(TransactionState::ABORTED);
          throw TransactionAbortException(txn->GetTransactionId(), AbortReason::LOCK_ON_SHRINKING);
        }
        case TransactionState::ABORTED:
          return false;
        case TransactionState::COMMITTED:
          break;
      }
    } break;
    case IsolationLevel::READ_COMMITTED: {
      switch (txn->GetState()) {
        case TransactionState::GROWING:
          // All locks are allowed in the GROWING state
          return true;
        case TransactionState::SHRINKING: {
          // Only IS, S locks are allowed in the SHRINKING state
          switch (lock_mode) {
            case LockMode::SHARED:
            case LockMode::INTENTION_SHARED:
              return true;
            case LockMode::EXCLUSIVE:
            case LockMode::INTENTION_EXCLUSIVE:
            case LockMode::SHARED_INTENTION_EXCLUSIVE:
              txn->SetState(TransactionState::ABORTED);
              throw TransactionAbortException(txn->GetTransactionId(), AbortReason::LOCK_ON_SHRINKING);
          }
        } break;
        case TransactionState::ABORTED:
          return false;
        case TransactionState::COMMITTED:
          break;
      }
    } break;
    case IsolationLevel::REPEATABLE_READ: {
      switch (txn->GetState()) {
        case TransactionState::GROWING:
          // All locks are allowed in the GROWING state
          return true;
        case TransactionState::SHRINKING: {
          // No locks are allowed in the SHRINKING state
          txn->SetState(TransactionState::ABORTED);
          throw TransactionAbortException(txn->GetTransactionId(), AbortReason::LOCK_ON_SHRINKING);
        } break;
        case TransactionState::ABORTED:
          return false;
        case TransactionState::COMMITTED:
          break;
      }
    } break;
  }
  return false;
}

auto LockManager::AreLocksCompatible(LockMode l1, LockMode l2) -> bool {
  switch (l1) {
    case LockMode::INTENTION_SHARED: {
      switch (l2) {
        case LockMode::SHARED:
        case LockMode::INTENTION_SHARED:
        case LockMode::INTENTION_EXCLUSIVE:
        case LockMode::SHARED_INTENTION_EXCLUSIVE:
          return true;
        case LockMode::EXCLUSIVE:
          return false;
      }
    } break;
    case LockMode::INTENTION_EXCLUSIVE: {
      switch (l2) {
        case LockMode::INTENTION_SHARED:
        case LockMode::INTENTION_EXCLUSIVE:
          return true;
        case LockMode::SHARED:
        case LockMode::SHARED_INTENTION_EXCLUSIVE:
        case LockMode::EXCLUSIVE:
          return false;
      }
    } break;
    case LockMode::SHARED_INTENTION_EXCLUSIVE: {
      switch (l2) {
        case LockMode::INTENTION_SHARED:
          return true;
        case LockMode::SHARED:
        case LockMode::INTENTION_EXCLUSIVE:
        case LockMode::SHARED_INTENTION_EXCLUSIVE:
        case LockMode::EXCLUSIVE:
          return false;
      }
    } break;
    case LockMode::SHARED: {
      switch (l2) {
        case LockMode::SHARED:
        case LockMode::INTENTION_SHARED:
          return true;
        case LockMode::INTENTION_EXCLUSIVE:
        case LockMode::SHARED_INTENTION_EXCLUSIVE:
        case LockMode::EXCLUSIVE:
          return false;
      }
    } break;
    case LockMode::EXCLUSIVE:
      return false;
  }
  return false;
}

void LockManager::GrantNewLocksIfPossible(LockRequestQueue *lock_request_queue, LockRequest *lock_request) {
  lock_request->granted_ = true;
  if (lock_request_queue->upgrading_ == lock_request->txn_id_) {
    lock_request_queue->upgrading_ = INVALID_TXN_ID;
  }
}

auto LockManager::CanLockUpgrade(LockMode curr_lock_mode, LockMode requested_lock_mode) -> bool {
  // While upgrading, only the following transitions should be allowed:
  //   IS -> [S, X, IX, SIX]
  //   S -> [X, SIX]
  //   IX -> [X, SIX]
  //   SIX -> [X]
  switch (curr_lock_mode) {
    case LockMode::INTENTION_SHARED: {
      switch (requested_lock_mode) {
        case LockMode::SHARED:
        case LockMode::EXCLUSIVE:
        case LockMode::INTENTION_EXCLUSIVE:
        case LockMode::SHARED_INTENTION_EXCLUSIVE:
          return true;
        case LockMode::INTENTION_SHARED:
          break;
      }
    } break;
    case LockMode::INTENTION_EXCLUSIVE:
    case LockMode::SHARED: {
      switch (requested_lock_mode) {
        case LockMode::EXCLUSIVE:
        case LockMode::SHARED_INTENTION_EXCLUSIVE:
          return true;
        case LockMode::SHARED:
        case LockMode::INTENTION_SHARED:
        case LockMode::INTENTION_EXCLUSIVE:
          break;
      }
    } break;
    case LockMode::SHARED_INTENTION_EXCLUSIVE: {
      switch (requested_lock_mode) {
        case LockMode::EXCLUSIVE:
          return true;
        case LockMode::SHARED:
        case LockMode::INTENTION_SHARED:
        case LockMode::INTENTION_EXCLUSIVE:
        case LockMode::SHARED_INTENTION_EXCLUSIVE:
          break;
      }
    } break;
    case LockMode::EXCLUSIVE:
      break;
  }
  return false;
}

auto LockManager::CheckAppropriateLockOnTable(Transaction *txn, const table_oid_t &oid, LockMode row_lock_mode)
    -> bool {
  switch (row_lock_mode) {
    case LockMode::INTENTION_SHARED:
    case LockMode::INTENTION_EXCLUSIVE:
    case LockMode::SHARED_INTENTION_EXCLUSIVE:
      txn->SetState(TransactionState::ABORTED);
      throw TransactionAbortException(txn->GetTransactionId(), AbortReason::ATTEMPTED_INTENTION_LOCK_ON_ROW);
    case LockMode::EXCLUSIVE:
      if (txn->GetIntentionExclusiveTableLockSet()->count(oid) == 0 &&
          txn->GetExclusiveTableLockSet()->count(oid) == 0 &&
          txn->GetSharedIntentionExclusiveTableLockSet()->count(oid) == 0) {
        txn->SetState(TransactionState::ABORTED);
        throw TransactionAbortException(txn->GetTransactionId(), AbortReason::TABLE_LOCK_NOT_PRESENT);
      }
      break;
    case LockMode::SHARED:
      if (txn->GetIntentionSharedTableLockSet()->count(oid) == 0 && txn->GetSharedTableLockSet()->count(oid) == 0 &&
          txn->GetIntentionExclusiveTableLockSet()->count(oid) == 0 &&
          txn->GetExclusiveTableLockSet()->count(oid) == 0 &&
          txn->GetSharedIntentionExclusiveTableLockSet()->count(oid) == 0) {
        txn->SetState(TransactionState::ABORTED);
        throw TransactionAbortException(txn->GetTransactionId(), AbortReason::TABLE_LOCK_NOT_PRESENT);
      }
      break;
  }
  return true;
}

auto LockManager::UpgradeLockTable(Transaction *txn, LockMode lock_mode, const table_oid_t &oid) -> bool {
  // concurrent control
  std::unique_lock<std::mutex> lock_manager_guard(this->table_lock_map_latch_);
  if (this->table_lock_map_.count(oid) == 0) {
    this->table_lock_map_[oid] = std::make_shared<LockRequestQueue>();
  }
  auto lock_request_queue = this->table_lock_map_.at(oid);
  lock_manager_guard.unlock();

  // table lock request queue concurrent control
  std::unique_lock<std::mutex> lock_request_queue_guard(lock_request_queue->latch_);

  std::vector<std::shared_ptr<LockRequest>> cur_lock_request;
  for (const auto &lr : lock_request_queue->request_queue_) {
    if (lr->granted_ && lr->txn_id_ == txn->GetTransactionId()) {
      // If requested lock mode is the same as that of the lock presently held,
      // Lock() should return true since it already has the lock.
      if (lr->lock_mode_ == lock_mode) {
        return true;
      }
      cur_lock_request.emplace_back(lr);
    }
  }

  if (cur_lock_request.empty()) {
    auto new_lock_request = std::make_shared<LockRequest>(LockRequest{txn->GetTransactionId(), lock_mode, oid});
    lock_request_queue->request_queue_.emplace_back(new_lock_request);
    while (!this->GrantLock(lock_request_queue.get(), new_lock_request.get())) {
      lock_request_queue->cv_.wait(lock_request_queue_guard);
      // If the transaction was aborted in the meantime, do not grant the lock and return false.
      if (txn->GetState() == TransactionState::ABORTED) {
        lock_request_queue->request_queue_.remove(new_lock_request);
        lock_request_queue->cv_.notify_all();
        return false;
      }
    }
    this->GrantNewLocksIfPossible(lock_request_queue.get(), new_lock_request.get());
    // book keeping
    this->BookkeepInsertTable(txn, lock_mode, oid);

    return true;
  }

  for (const auto &lr : cur_lock_request) {
    // If requested lock mode is different, Lock() should upgrade the lock held by the transaction.
    if (!this->CanLockUpgrade(lr->lock_mode_, lock_mode)) {
      txn->SetState(TransactionState::ABORTED);
      throw TransactionAbortException(txn->GetTransactionId(), AbortReason::INCOMPATIBLE_UPGRADE);
    }
    // Multiple concurrent lock upgrades on the same resource should set the TransactionState as
    // ABORTED and throw a TransactionAbortException(UPGRADE_CONFLICT).
    if (lock_request_queue->upgrading_ != INVALID_TXN_ID) {
      txn->SetState(TransactionState::ABORTED);
      throw TransactionAbortException(txn->GetTransactionId(), AbortReason::UPGRADE_CONFLICT);
    }
    // release held lock
    lock_request_queue->request_queue_.remove(lr);
    this->BookkeepRemoveTable(txn, lr->lock_mode_, oid);
    // start upgrading
    lock_request_queue->upgrading_ = txn->GetTransactionId();

    auto new_lock_request = std::make_shared<LockRequest>(LockRequest{txn->GetTransactionId(), lock_mode, oid});
    lock_request_queue->request_queue_.emplace_back(new_lock_request);
    while (!this->GrantLock(lock_request_queue.get(), new_lock_request.get())) {
      lock_request_queue->cv_.wait(lock_request_queue_guard);
      // If the transaction was aborted in the meantime, do not grant the lock and return false.
      if (txn->GetState() == TransactionState::ABORTED) {
        lock_request_queue->upgrading_ = INVALID_TXN_ID;
        lock_request_queue->request_queue_.remove(new_lock_request);
        lock_request_queue->cv_.notify_all();
        return false;
      }
    }
    this->GrantNewLocksIfPossible(lock_request_queue.get(), new_lock_request.get());
    // book keeping
    this->BookkeepInsertTable(txn, lock_mode, oid);
  }

  return true;
}

auto LockManager::LockTable(Transaction *txn, LockMode lock_mode, const table_oid_t &oid) -> bool {
  return this->CanTxnTakeLock(txn, lock_mode) && this->UpgradeLockTable(txn, lock_mode, oid);
}

auto LockManager::UnlockTable(Transaction *txn, const table_oid_t &oid) -> bool {
  // If the transaction holds locks on rows of the table, Unlock should set the Transaction State
  // as ABORTED and throw a TransactionAbortException (TABLE_UNLOCKED_BEFORE_UNLOCKING_ROWS).
  auto row_x_lock_set = txn->GetExclusiveRowLockSet();
  if (row_x_lock_set->count(oid) != 0) {
    if (!row_x_lock_set->at(oid).empty()) {
      txn->SetState(TransactionState::ABORTED);
      throw TransactionAbortException(txn->GetTransactionId(), AbortReason::TABLE_UNLOCKED_BEFORE_UNLOCKING_ROWS);
    }
  }
  auto row_s_lock_set = txn->GetSharedRowLockSet();
  if (row_s_lock_set->count(oid) != 0) {
    if (!row_s_lock_set->at(oid).empty()) {
      txn->SetState(TransactionState::ABORTED);
      throw TransactionAbortException(txn->GetTransactionId(), AbortReason::TABLE_UNLOCKED_BEFORE_UNLOCKING_ROWS);
    }
  }

  // concurrent control
  std::unique_lock<std::mutex> table_lock_manager_guard(this->table_lock_map_latch_);
  if (this->table_lock_map_.count(oid) == 0) {
    txn->SetState(TransactionState::ABORTED);
    throw TransactionAbortException(txn->GetTransactionId(), AbortReason::TABLE_LOCK_NOT_PRESENT);
  }
  auto lock_request_queue = this->table_lock_map_.at(oid);
  table_lock_manager_guard.unlock();

  std::scoped_lock<std::mutex> lock_request_queue_guard(lock_request_queue->latch_);
  std::vector<std::shared_ptr<LockRequest>> cur_lock_request;
  for (const auto &lr : lock_request_queue->request_queue_) {
    if (lr->granted_ && lr->txn_id_ == txn->GetTransactionId() && lr->oid_ == oid) {
      cur_lock_request.emplace_back(lr);
    }
  }
  // If not, LockManager should set the TransactionState as ABORTED and throw
  // a TransactionAbortException (ATTEMPTED_UNLOCK_BUT_NO_LOCK_HELD)
  if (cur_lock_request.empty()) {
    txn->SetState(TransactionState::ABORTED);
    throw TransactionAbortException(txn->GetTransactionId(), AbortReason::ATTEMPTED_UNLOCK_BUT_NO_LOCK_HELD);
  }

  for (const auto &lr : cur_lock_request) {
    this->UnlockRequestQueue(txn, lr.get());

    lock_request_queue->request_queue_.remove(lr);
    lock_request_queue->cv_.notify_all();

    // bookkeeping
    this->BookkeepRemoveTable(txn, lr->lock_mode_, oid);
  }
  return true;
}

auto LockManager::UpgradeLockRow(Transaction *txn, LockMode lock_mode, const table_oid_t &oid, const RID &rid) -> bool {
  // concurrent control
  std::unique_lock<std::mutex> row_lock_manager_guard(this->row_lock_map_latch_);
  if (this->row_lock_map_.count(rid) == 0) {
    this->row_lock_map_[rid] = std::make_shared<LockRequestQueue>();
  }
  auto lock_request_queue = this->row_lock_map_.at(rid);
  row_lock_manager_guard.unlock();

  // row lock request queue concurrent control
  std::unique_lock<std::mutex> lock_request_queue_guard(lock_request_queue->latch_);

  std::vector<std::shared_ptr<LockRequest>> cur_lock_request;
  for (const auto &lr : lock_request_queue->request_queue_) {
    if (lr->granted_ && lr->txn_id_ == txn->GetTransactionId()) {
      // If requested lock mode is the same as that of the lock presently held,
      // Lock() should return true since it already has the lock.
      if (lr->lock_mode_ == lock_mode) {
        return true;
      }
      cur_lock_request.emplace_back(lr);
    }
  }

  if (cur_lock_request.empty()) {
    auto new_lock_request = std::make_shared<LockRequest>(LockRequest{txn->GetTransactionId(), lock_mode, oid, rid});
    lock_request_queue->request_queue_.emplace_back(new_lock_request);

    while (!this->GrantLock(lock_request_queue.get(), new_lock_request.get())) {
      lock_request_queue->cv_.wait(lock_request_queue_guard);
      // If the transaction was aborted in the meantime, do not grant the lock and return false.
      if (txn->GetState() == TransactionState::ABORTED) {
        lock_request_queue->request_queue_.remove(new_lock_request);
        lock_request_queue->cv_.notify_all();
        return false;
      }
    }
    this->GrantNewLocksIfPossible(lock_request_queue.get(), new_lock_request.get());
    // book keeping
    this->BookkeepInsertRow(txn, lock_mode, oid, rid);
    return true;
  }

  for (const auto &lr : cur_lock_request) {
    // Multiple concurrent lock upgrades on the same resource should set the TransactionState as
    // ABORTED and throw a TransactionAbortException(UPGRADE_CONFLICT).
    if (lock_request_queue->upgrading_ != INVALID_TXN_ID) {
      txn->SetState(TransactionState::ABORTED);
      throw TransactionAbortException(txn->GetTransactionId(), AbortReason::UPGRADE_CONFLICT);
    }
    // If requested lock mode is different, Lock() should upgrade the lock held by the transaction.
    if (!this->CanLockUpgrade(lr->lock_mode_, lock_mode)) {
      txn->SetState(TransactionState::ABORTED);
      throw TransactionAbortException(txn->GetTransactionId(), AbortReason::INCOMPATIBLE_UPGRADE);
    }
    // release held lock
    lock_request_queue->request_queue_.remove(lr);
    this->BookkeepRemoveRow(txn, lr->lock_mode_, oid, rid);
    // start upgrading
    lock_request_queue->upgrading_ = txn->GetTransactionId();
    auto new_lock_request = std::make_shared<LockRequest>(LockRequest{txn->GetTransactionId(), lock_mode, oid, rid});
    lock_request_queue->request_queue_.emplace_back(new_lock_request);

    while (!this->GrantLock(lock_request_queue.get(), new_lock_request.get())) {
      lock_request_queue->cv_.wait(lock_request_queue_guard);
      // If the transaction was aborted in the meantime, do not grant the lock and return false.
      if (txn->GetState() == TransactionState::ABORTED) {
        lock_request_queue->upgrading_ = INVALID_TXN_ID;
        lock_request_queue->request_queue_.remove(new_lock_request);
        lock_request_queue->cv_.notify_all();
        return false;
      }
    }
    this->GrantNewLocksIfPossible(lock_request_queue.get(), new_lock_request.get());
    // book keeping
    this->BookkeepInsertRow(txn, lock_mode, oid, rid);
  }
  return true;
}

auto LockManager::LockRow(Transaction *txn, LockMode lock_mode, const table_oid_t &oid, const RID &rid) -> bool {
  return this->CheckAppropriateLockOnTable(txn, oid, lock_mode) && this->CanTxnTakeLock(txn, lock_mode) &&
         this->UpgradeLockRow(txn, lock_mode, oid, rid);
}

auto LockManager::UnlockRow(Transaction *txn, const table_oid_t &oid, const RID &rid, bool force) -> bool {
  // concurrent control
  std::unique_lock<std::mutex> row_lock_manager_guard(this->row_lock_map_latch_);
  if (this->row_lock_map_.count(rid) == 0) {
    txn->SetState(TransactionState::ABORTED);
    throw TransactionAbortException(txn->GetTransactionId(), AbortReason::ATTEMPTED_UNLOCK_BUT_NO_LOCK_HELD);
  }
  auto lock_request_queue = this->row_lock_map_.at(rid);
  row_lock_manager_guard.unlock();

  std::scoped_lock<std::mutex> lock_request_queue_guard(lock_request_queue->latch_);
  std::vector<std::shared_ptr<LockRequest>> cur_lock_request;
  for (const auto &lr : lock_request_queue->request_queue_) {
    if (lr->granted_ && lr->txn_id_ == txn->GetTransactionId() && lr->oid_ == oid && lr->rid_ == rid) {
      cur_lock_request.emplace_back(lr);
    }
  }
  // If not, LockManager should set the TransactionState as ABORTED and throw
  // a TransactionAbortException (ATTEMPTED_UNLOCK_BUT_NO_LOCK_HELD)
  if (cur_lock_request.empty()) {
    txn->SetState(TransactionState::ABORTED);
    throw TransactionAbortException(txn->GetTransactionId(), AbortReason::ATTEMPTED_UNLOCK_BUT_NO_LOCK_HELD);
  }

  for (const auto &lr : cur_lock_request) {
    if (!force) {
      this->UnlockRequestQueue(txn, lr.get());
    }

    lock_request_queue->request_queue_.remove(lr);
    lock_request_queue->cv_.notify_all();

    // bookkeeping
    this->BookkeepRemoveRow(txn, lr->lock_mode_, oid, rid);
  }
  return true;
}

void LockManager::UnlockAll() {
  // You probably want to unlock all table and txn locks here.
}

auto LockManager::FindCycle(txn_id_t source_txn, std::unordered_set<txn_id_t> &on_path,
                            std::unordered_set<txn_id_t> &visited) -> bool {
  visited.insert(source_txn);
  on_path.insert(source_txn);
  std::sort(this->waits_for_[source_txn].begin(), this->waits_for_[source_txn].end());
  for (auto e : this->waits_for_[source_txn]) {
    if (visited.count(e) == 0) {
      if (this->FindCycle(e, on_path, visited)) {
        return true;
      }
    } else if (on_path.count(e) > 0) {
      return true;
    }
  }
  on_path.erase(source_txn);
  return false;
}

void LockManager::AddEdge(txn_id_t t1, txn_id_t t2) {
  if (t1 == t2) {
    return;
  }
  // If the edge already exists, you don't have to do anything.
  for (auto &it : this->waits_for_[t1]) {
    if (it == t2) {
      return;
    }
  }
  // exploring neighbors in order (by transaction id) when searching from a node.
  this->waits_for_[t1].emplace_back(t2);
}

void LockManager::RemoveEdge(txn_id_t t1, txn_id_t t2) {
  auto &v = this->waits_for_[t1];
  auto it = std::remove(v.begin(), v.end(), t2);
  v.erase(it, v.end());
}

auto LockManager::HasCycle(txn_id_t *txn_id) -> bool {
  // starting the depth-first search from the node with lowest transaction id and
  std::vector<txn_id_t> path;
  path.reserve(this->waits_for_.size());
  for (const auto &n : this->waits_for_) {
    path.emplace_back(n.first);
  }
  std::sort(path.begin(), path.end());

  std::unordered_set<txn_id_t> on_path;
  std::unordered_set<txn_id_t> visited;
  for (const auto &n : path) {
    if (visited.count(n) == 0) {
      if (this->FindCycle(n, on_path, visited)) {
        *txn_id = n;
        for (auto tid : on_path) {
          // abort the youngest transaction to break the cycle
          *txn_id = std::max(*txn_id, tid);
        }
        return true;
      }
    }
  }
  return false;
}

auto LockManager::GetEdgeList() -> std::vector<std::pair<txn_id_t, txn_id_t>> {
  std::vector<std::pair<txn_id_t, txn_id_t>> edges(0);
  for (const auto &n : this->waits_for_) {
    for (const auto &e : n.second) {
      edges.emplace_back(n.first, e);
    }
  }
  return edges;
}

void LockManager::RunCycleDetection() {
  while (enable_cycle_detection_) {
    std::this_thread::sleep_for(cycle_detection_interval);
    {  // TODO(students): detect deadlock
      std::map<txn_id_t, table_oid_t> txn2table_waiting_map;
      std::map<txn_id_t, RID> txn2row_waiting_map;

      std::scoped_lock<std::mutex> graph_lock(this->waits_for_latch_);
      // it should be built every time the deadlock detection thread wakes up.
      std::unique_lock<std::mutex> table_guard(this->table_lock_map_latch_);
      for (const auto &t : this->table_lock_map_) {
        std::scoped_lock<std::mutex> lock_request_queue_guard(t.second->latch_);
        std::vector<txn_id_t> waiting_request;
        std::vector<txn_id_t> granted_request;
        for (const auto &lr : t.second->request_queue_) {
          auto txn = this->txn_manager_->GetTransaction(lr->txn_id_);
          if (txn->GetState() == TransactionState::ABORTED) {
            continue;
          }
          if (lr->granted_) {
            granted_request.emplace_back(lr->txn_id_);
          } else {
            txn2table_waiting_map[txn->GetTransactionId()] = lr->oid_;
            waiting_request.emplace_back(lr->txn_id_);
          }
        }
        for (const auto &w : waiting_request) {
          for (const auto &g : granted_request) {
            this->AddEdge(w, g);
          }
        }
      }
      table_guard.unlock();

      std::unique_lock<std::mutex> row_guard(this->row_lock_map_latch_);
      for (const auto &r : this->row_lock_map_) {
        std::scoped_lock<std::mutex> lock_request_queue_guard(r.second->latch_);
        std::vector<txn_id_t> waiting_request;
        std::vector<txn_id_t> granted_request;
        for (const auto &lr : r.second->request_queue_) {
          auto txn = this->txn_manager_->GetTransaction(lr->txn_id_);
          if (txn->GetState() == TransactionState::ABORTED) {
            continue;
          }
          if (lr->granted_) {
            granted_request.emplace_back(lr->txn_id_);
          } else {
            txn2row_waiting_map[lr->txn_id_] = lr->rid_;
            waiting_request.emplace_back(lr->txn_id_);
          }
        }
        for (const auto &w : waiting_request) {
          for (const auto &g : granted_request) {
            this->AddEdge(w, g);
          }
        }
      }
      row_guard.unlock();

      txn_id_t aborted_txn_id;
      while (this->HasCycle(&aborted_txn_id)) {
        auto txn = this->txn_manager_->GetTransaction(aborted_txn_id);
        // release lock
        this->txn_manager_->Abort(txn);
        // notify waiting lock request
        if (txn2table_waiting_map.count(aborted_txn_id) > 0) {
          this->table_lock_map_latch_.lock();
          auto lrq = this->table_lock_map_[txn2table_waiting_map.at(aborted_txn_id)];
          this->table_lock_map_latch_.unlock();
          lrq->cv_.notify_all();
        }
        if (txn2row_waiting_map.count(aborted_txn_id) > 0) {
          this->row_lock_map_latch_.lock();
          auto lrq = this->row_lock_map_[txn2row_waiting_map.at(aborted_txn_id)];
          this->row_lock_map_latch_.unlock();
          lrq->cv_.notify_all();
        }

        // update graph
        this->waits_for_.erase(aborted_txn_id);
        for (const auto &n : this->waits_for_) {
          this->RemoveEdge(n.first, aborted_txn_id);
        }
      }

      // it should be destroyed every time the deadlock detection thread finishes.
      this->waits_for_.clear();
    }
  }
}

}  // namespace bustub
