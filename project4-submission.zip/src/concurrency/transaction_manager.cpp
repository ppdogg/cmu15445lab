//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// transaction_manager.cpp
//
// Identification: src/concurrency/transaction_manager.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "concurrency/transaction_manager.h"

#include <mutex>  // NOLINT
#include <shared_mutex>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#include "catalog/catalog.h"
#include "common/config.h"
#include "common/macros.h"
#include "concurrency/transaction.h"
#include "storage/table/table_heap.h"
#include "storage/table/tuple.h"
namespace bustub {

void TransactionManager::Commit(Transaction *txn) {
  // Release all the locks.
  ReleaseLocks(txn);

  txn->SetState(TransactionState::COMMITTED);
}

void TransactionManager::Abort(Transaction *txn) {
  /* TODO: revert all the changes in write set */
  while (!txn->GetWriteSet()->empty()) {
    auto &record = txn->GetWriteSet()->back();
    switch (record.wtype_) {
      case WType::INSERT:
        record.table_heap_->UpdateTupleMeta({INVALID_TXN_ID, INVALID_TXN_ID, true}, record.rid_);
        break;
      case WType::DELETE:
        record.table_heap_->UpdateTupleMeta({INVALID_TXN_ID, INVALID_TXN_ID, false}, record.rid_);
        break;
      case WType::UPDATE:
        break;
    }
    txn->GetWriteSet()->pop_back();
  }
  txn->GetWriteSet()->clear();

  while (!txn->GetIndexWriteSet()->empty()) {
    auto &record = txn->GetIndexWriteSet()->back();
    auto index_info = record.catalog_->GetIndex(record.index_oid_);
    auto table_info = record.catalog_->GetTable(record.table_oid_);
    auto key =
        record.tuple_.KeyFromTuple(table_info->schema_, index_info->key_schema_, index_info->index_->GetKeyAttrs());
    switch (record.wtype_) {
      case WType::INSERT:
        index_info->index_->DeleteEntry(key, record.rid_, txn);
        break;
      case WType::DELETE:
        index_info->index_->InsertEntry(key, record.rid_, txn);
        break;
      case WType::UPDATE:
        break;
    }
    txn->GetIndexWriteSet()->pop_back();
  }
  txn->GetIndexWriteSet()->clear();

  ReleaseLocks(txn);

  txn->SetState(TransactionState::ABORTED);
}

void TransactionManager::BlockAllTransactions() { UNIMPLEMENTED("block is not supported now!"); }

void TransactionManager::ResumeTransactions() { UNIMPLEMENTED("resume is not supported now!"); }

}  // namespace bustub
