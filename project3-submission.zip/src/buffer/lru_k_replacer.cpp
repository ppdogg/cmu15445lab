//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
// Copyright (c) 2015-2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <map>
#include "common/config.h"
#include "common/exception.h"
#include "fmt/format.h"

namespace bustub {

auto LRUKNode::HaveKDistance() const -> bool { return this->history_.size() >= this->k_; }

auto LRUKNode::GetLeastTime(size_t curTime) const -> size_t {
  return this->HaveKDistance() ? curTime - this->history_.back() : this->history_.front();
}

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {}

auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  std::scoped_lock<std::mutex> guard(this->latch_);

  std::map<size_t, frame_id_t> rec_inf;
  std::map<size_t, frame_id_t> rec_k_dis;
  for (auto const &[fId, fNode] : this->node_store_) {
    // inevictable
    if (!fNode.IsEvictable()) {
      continue;
    }

    size_t dis = fNode.GetLeastTime(this->current_timestamp_);
    if (fNode.HaveKDistance()) {
      rec_k_dis[dis] = fId;
    } else {
      rec_inf[dis] = fId;
    }
  }

  if (!rec_inf.empty()) {
    *frame_id = rec_inf.begin()->second;
    //  frame not evictable
    if (!this->node_store_.at(*frame_id).IsEvictable()) {
      return false;
    }

    // remove frame
    if (this->node_store_.erase(*frame_id) == 1) {
      // decrement replacer's size if removal is successful.
      this->curr_size_--;
    }
    return true;
  }
  if (!rec_k_dis.empty()) {
    *frame_id = rec_k_dis.rbegin()->second;
    //  frame not evictable
    if (!this->node_store_.at(*frame_id).IsEvictable()) {
      return false;
    }

    // remove frame
    if (this->node_store_.erase(*frame_id) == 1) {
      // decrement replacer's size if removal is successful.
      this->curr_size_--;
    }
    return true;
  }

  return false;
}

void LRUKReplacer::RecordAccess(frame_id_t frame_id, [[maybe_unused]] AccessType access_type) {
  std::scoped_lock<std::mutex> guard(this->latch_);
  // check if frame id is legal
  if (frame_id < 0) {
    throw Exception("frame id is illegal");
  }
  if (static_cast<size_t>(frame_id) > this->replacer_size_) {
    throw Exception("frame id is illegal");
  }

  // get node and create new entry if the frame is used for the first time
  if (this->node_store_.count(frame_id) == 0) {
    this->node_store_[frame_id] = LRUKNode(frame_id, this->k_);
  }

  this->current_timestamp_++;
  this->node_store_[frame_id].AddHistory(this->current_timestamp_);
}

void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  std::scoped_lock<std::mutex> guard(this->latch_);
  // check if frame id is legal
  if (frame_id < 0) {
    throw Exception("frame id is illegal");
  }
  if (static_cast<size_t>(frame_id) > this->replacer_size_) {
    throw Exception("frame id is illegal");
  }

  // frame not found
  if (this->node_store_.count(frame_id) == 0) {
    return;
  }

  auto &node = this->node_store_.at(frame_id);
  if (node.IsEvictable() && !set_evictable) {
    this->curr_size_--;
  } else if (!node.IsEvictable() && set_evictable) {
    this->curr_size_++;
  }
  node.SetEvictable(set_evictable);
}

void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::scoped_lock<std::mutex> guard(this->latch_);
  // frame not found
  if (this->node_store_.count(frame_id) == 0) {
    return;
  }
  // frame not evictable
  if (!this->node_store_.at(frame_id).IsEvictable()) {
    throw Exception(fmt::format("frame id {} is not evictable", frame_id));
  }

  // remove frame
  this->node_store_.erase(frame_id);
  this->curr_size_--;
}

auto LRUKReplacer::Size() -> size_t {
  std::scoped_lock<std::mutex> guard(this->latch_);
  return this->curr_size_;
}

}  // namespace bustub
