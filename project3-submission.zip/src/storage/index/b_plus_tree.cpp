#include <cstdlib>
#include <iostream>
#include <ostream>
#include <sstream>
#include <string>
#include <utility>

#include "common/config.h"
#include "common/exception.h"
#include "common/logger.h"
#include "common/rid.h"
#include "storage/index/b_plus_tree.h"
#include "storage/page/b_plus_tree_page.h"
#include "storage/page/hash_table_page_defs.h"

namespace bustub {

INDEX_TEMPLATE_ARGUMENTS
BPLUSTREE_TYPE::BPlusTree(std::string name, page_id_t header_page_id, BufferPoolManager *buffer_pool_manager,
                          const KeyComparator &comparator, int leaf_max_size, int internal_max_size)
    : index_name_(std::move(name)),
      bpm_(buffer_pool_manager),
      comparator_(std::move(comparator)),
      leaf_max_size_(leaf_max_size),
      internal_max_size_(internal_max_size),
      header_page_id_(header_page_id) {
  WritePageGuard guard = bpm_->FetchPageWrite(header_page_id_);
  auto root_page = guard.AsMut<BPlusTreeHeaderPage>();
  root_page->root_page_id_ = INVALID_PAGE_ID;
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Get2LeafnodeRead(Context &ctx, page_id_t page_id, const KeyType &key) {
  ReadPageGuard read_guard = this->bpm_->FetchPageRead(page_id);

  auto node_page_ptr = read_guard.As<BPlusTreePage>();
  // search in internal node
  while (!node_page_ptr->IsLeafPage()) {
    auto internal_page_ptr = reinterpret_cast<const InternalPage *>(node_page_ptr);
    auto i = internal_page_ptr->SearchKey(key, this->comparator_);
    auto page_id = internal_page_ptr->ValueAt(i);

    // drop and reassign
    read_guard = std::move(this->bpm_->FetchPageRead(page_id));
    node_page_ptr = read_guard.As<BPlusTreePage>();
  }

  ctx.read_set_.emplace_back(std::move(read_guard));
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Get2LeafnodeWrite(Context &ctx, page_id_t page_id, const KeyType &key, bool flag) {
  auto is_safe = [](bool flag, const BPlusTreePage *node_ptr) -> bool {
    return flag ? node_ptr->GetSize() < node_ptr->GetMaxSize() : node_ptr->GetMinSize() < node_ptr->GetSize();
  };

  // Improved Latch Crabbing Protocol
  ReadPageGuard root_read_guard = this->bpm_->FetchPageRead(page_id);
  auto c_node_page_ptr = root_read_guard.As<BPlusTreePage>();
  while (!c_node_page_ptr->IsLeafPage()) {
    auto internal_page_ptr = reinterpret_cast<const InternalPage *>(c_node_page_ptr);
    auto i = internal_page_ptr->SearchKey(key, this->comparator_);
    auto page_id = internal_page_ptr->ValueAt(i);
    root_read_guard = std::move(this->bpm_->FetchPageRead(page_id));
    c_node_page_ptr = root_read_guard.As<BPlusTreePage>();
  }
  auto leaf_page_id = root_read_guard.PageId();
  root_read_guard.Drop();
  WritePageGuard leaf_write_guard = this->bpm_->FetchPageWrite(leaf_page_id);
  auto leaf_page_ptr = leaf_write_guard.AsMut<LeafPage>();
  // check if leaf node is safe
  if (is_safe(flag, leaf_page_ptr)) {
    if (ctx.header_page_.has_value()) {
      ctx.header_page_->Drop();
      ctx.header_page_ = std::nullopt;
    }
    ctx.write_set_.emplace_back(std::move(leaf_write_guard));
    return;
  }
  // release previous node
  leaf_write_guard.Drop();

  // Basic Latch Crabbing Protocol
  WritePageGuard root_write_guard = this->bpm_->FetchPageWrite(page_id);
  auto node_page_ptr = root_write_guard.AsMut<BPlusTreePage>();
  // search in internal node
  while (!node_page_ptr->IsLeafPage()) {
    auto internal_page_ptr = reinterpret_cast<InternalPage *>(node_page_ptr);
    auto i = internal_page_ptr->SearchKey(key, this->comparator_);
    auto page_id = internal_page_ptr->ValueAt(i);

    ctx.write_set_.emplace_back(std::move(root_write_guard));
    root_write_guard = this->bpm_->FetchPageWrite(page_id);
    node_page_ptr = root_write_guard.AsMut<BPlusTreePage>();
  }

  ctx.write_set_.emplace_back(std::move(root_write_guard));
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ReleaseContext(Context &ctx) {
  if (ctx.header_page_.has_value()) {
    ctx.header_page_->Drop();
  }
  ctx.header_page_ = std::nullopt;
  ctx.root_page_id_ = INVALID_PAGE_ID;
  // release lock
  auto len = ctx.write_set_.size();
  for (size_t i = 0; i < len; i++) {
    ctx.write_set_.pop_front();
  }
  len = ctx.read_set_.size();
  for (size_t i = 0; i < len; i++) {
    ctx.read_set_.pop_front();
  }
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::StartNewRoot(Context &ctx) {
  page_id_t root_page_id;
  // start a new tree
  BasicPageGuard new_page_guard = this->bpm_->NewPageGuarded(&root_page_id);
  new_page_guard.Drop();
  WritePageGuard root_page_guard = this->bpm_->FetchPageWrite(root_page_id);
  auto leaf_page_ptr = root_page_guard.AsMut<LeafPage>();
  leaf_page_ptr->Init(this->leaf_max_size_);
  root_page_guard.Drop();
  // update root page id
  if (ctx.header_page_.has_value()) {
    auto header_page_ptr = ctx.header_page_.value().AsMut<BPlusTreeHeaderPage>();
    header_page_ptr->root_page_id_ = root_page_id;
  }
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::StartNewRoot(Context &ctx, const KeyType &key, page_id_t page_id1, page_id_t page_id2) {
  // create a new root
  page_id_t new_page_id = INVALID_PAGE_ID;
  BasicPageGuard guard = this->bpm_->NewPageGuarded(&new_page_id);
  guard.Drop();
  // init
  WritePageGuard write_guard = this->bpm_->FetchPageWrite(new_page_id);
  auto root_page_ptr = write_guard.AsMut<InternalPage>();
  root_page_ptr->Init(this->internal_max_size_);
  root_page_ptr->InitTwoChild(key, page_id1, page_id2);
  ctx.write_set_.emplace_back(std::move(write_guard));
  ctx.root_page_id_ = new_page_id;
  // update root
  if (ctx.header_page_.has_value()) {
    auto header_page_ptr = ctx.header_page_.value().AsMut<BPlusTreeHeaderPage>();
    header_page_ptr->root_page_id_ = new_page_id;
  }
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetFirstKey(page_id_t page_id) const -> KeyType {
  ReadPageGuard temp_page_guard = this->bpm_->FetchPageRead(page_id);
  auto temp_page = temp_page_guard.As<BPlusTreePage>();
  while (!temp_page->IsLeafPage()) {
    auto internal_page = reinterpret_cast<const InternalPage *>(temp_page);
    temp_page_guard = this->bpm_->FetchPageRead(internal_page->ValueAt(0));
    temp_page = temp_page_guard.As<BPlusTreePage>();
  }
  auto p = reinterpret_cast<const LeafPage *>(temp_page);
  return p->KeyAt(0);
}

/*
 * Helper function to decide whether current b+tree is empty
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::IsEmpty() const -> bool { return this->GetRootPageId() == INVALID_PAGE_ID; }
/*****************************************************************************
 * SEARCH
 *****************************************************************************/
/*
 * Return the only value that associated with input key
 * This method is used for point query
 * @return : true means key exists
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetValue(const KeyType &key, std::vector<ValueType> *result, Transaction *txn) -> bool {
  // Declaration of context instance.
  Context ctx;
  ctx.root_page_id_ = this->GetRootPageId();
  if (ctx.root_page_id_ == INVALID_PAGE_ID) {
    this->ReleaseContext(ctx);
    return false;
  }
  Get2LeafnodeRead(ctx, ctx.root_page_id_, key);
  ReadPageGuard read_guard = std::move(ctx.read_set_.front());
  ctx.read_set_.pop_front();
  this->ReleaseContext(ctx);

  // reach leaf node
  auto leaf_page_ptr = read_guard.As<const LeafPage>();
  auto i = leaf_page_ptr->SearchKey(key, this->comparator_);
  if (i >= 0 && this->comparator_(key, leaf_page_ptr->KeyAt(i)) == 0) {
    result->emplace_back(leaf_page_ptr->ValueAt(i));
    return true;
  }

  return false;
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Insert constant key & value pair into b+ tree
 * if current tree is empty, start new tree, update root page id and insert
 * entry, otherwise insert into leaf page.
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Insert(const KeyType &key, const ValueType &value, Transaction *txn) -> bool {
  if (this->header_page_id_ == INVALID_PAGE_ID) {
    return false;
  }

  // Declaration of context instance.
  Context ctx;
  ctx.header_page_ = this->bpm_->FetchPageWrite(this->header_page_id_);
  auto temp_page_ptr = ctx.header_page_->As<BPlusTreeHeaderPage>();
  if (temp_page_ptr->root_page_id_ == INVALID_PAGE_ID) {
    // update root
    this->StartNewRoot(ctx);
  }
  ctx.root_page_id_ = temp_page_ptr->root_page_id_;
  // search
  Get2LeafnodeWrite(ctx, ctx.root_page_id_, key, true);
  // reach leaf node
  auto node_page_ptr = ctx.write_set_.back().AsMut<BPlusTreePage>();
  auto leaf_page_ptr = reinterpret_cast<LeafPage *>(node_page_ptr);
  auto i = leaf_page_ptr->SearchKey(key, this->comparator_);
  // key already exists
  if (i >= 0 && this->comparator_(key, leaf_page_ptr->KeyAt(i)) == 0) {
    this->ReleaseContext(ctx);
    return false;
  }
  // insert key-value
  this->InsertAndSplitLeaf(ctx, key, value);
  // release context
  this->ReleaseContext(ctx);
  return true;
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertAndSplitLeaf(Context &ctx, const KeyType &key, const ValueType &value) {
  if (ctx.write_set_.empty()) {
    return;
  }
  auto cur_guard = std::move(ctx.write_set_.back());
  auto cur_page_id = cur_guard.PageId();
  ctx.write_set_.pop_back();
  auto node_page_ptr = cur_guard.AsMut<BPlusTreePage>();
  // leaf node
  auto leaf_page_ptr = reinterpret_cast<LeafPage *>(node_page_ptr);
  if (leaf_page_ptr->GetSize() < leaf_page_ptr->GetMaxSize()) {
    leaf_page_ptr->InsertKV(key, value, this->comparator_);
    return;
  }

  // malloc a temp memory area to in insert kv pair
  // length = leaf_max_size + 1
  auto *temp_leaf_node_ptr =
      static_cast<LeafPage *>(malloc(16 + (this->leaf_max_size_ + 1) * sizeof(std::pair<KeyType, ValueType>)));
  temp_leaf_node_ptr->Init(this->leaf_max_size_ + 1);
  temp_leaf_node_ptr->CopyFrom(leaf_page_ptr, 0);
  temp_leaf_node_ptr->InsertKV(key, value, this->comparator_);

  // start a new leaf node
  page_id_t new_page_id = INVALID_PAGE_ID;
  BasicPageGuard new_page_guard = this->bpm_->NewPageGuarded(&new_page_id);
  new_page_guard.Drop();
  WritePageGuard new_write_guard = this->bpm_->FetchPageWrite(new_page_id);
  auto new_leaf_page_ptr = new_write_guard.AsMut<LeafPage>();
  new_leaf_page_ptr->Init(this->leaf_max_size_);

  //          0 1 ... mid ... size size+1
  //                   ↓
  //     0 1 ... mid-1 && mid ... size size + 1
  auto mid_index = temp_leaf_node_ptr->GetSize() / 2;
  new_leaf_page_ptr->CopyFrom(temp_leaf_node_ptr, mid_index);
  leaf_page_ptr->SetSize(0);
  leaf_page_ptr->CopyFrom(temp_leaf_node_ptr, 0, mid_index);
  // update next_page_id
  new_leaf_page_ptr->SetNextPageId(leaf_page_ptr->GetNextPageId());
  leaf_page_ptr->SetNextPageId(new_page_id);

  // free temp memory
  free(temp_leaf_node_ptr);
  // current node is root node
  if (ctx.IsRootPage(cur_page_id)) {
    this->StartNewRoot(ctx, new_leaf_page_ptr->KeyAt(0), cur_page_id, new_page_id);
    return;
  }
  // update parent node
  this->InsertAndSplitInternal(ctx, new_leaf_page_ptr->KeyAt(0), new_page_id);
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertAndSplitInternal(Context &ctx, const KeyType &key, page_id_t page_id) {
  if (ctx.write_set_.empty()) {
    return;
  }
  auto cur_guard = std::move(ctx.write_set_.back());
  auto cur_page_id = cur_guard.PageId();
  ctx.write_set_.pop_back();
  auto node_page_ptr = cur_guard.AsMut<BPlusTreePage>();
  // internal node
  auto internal_page_ptr = reinterpret_cast<InternalPage *>(node_page_ptr);
  if (internal_page_ptr->GetSize() < internal_page_ptr->GetMaxSize()) {
    internal_page_ptr->InsertKV(key, page_id, this->comparator_);
    return;
  }

  // malloc a temp memory area to in insert kv pair
  // length = internal_max_size + 1
  auto *temp_internal_node_ptr =
      static_cast<InternalPage *>(malloc(12 + (this->internal_max_size_ + 1) * sizeof(std::pair<KeyType, page_id_t>)));
  temp_internal_node_ptr->Init(this->internal_max_size_ + 1);
  temp_internal_node_ptr->CopyFrom(internal_page_ptr, 0);
  temp_internal_node_ptr->InsertKV(key, page_id, this->comparator_);

  // start a new internal node
  page_id_t new_page_id = INVALID_PAGE_ID;
  BasicPageGuard new_page_guard = this->bpm_->NewPageGuarded(&new_page_id);
  new_page_guard.Drop();
  WritePageGuard new_write_guard = this->bpm_->FetchPageWrite(new_page_id);
  auto new_internal_page_ptr = new_write_guard.AsMut<InternalPage>();
  new_internal_page_ptr->Init(this->internal_max_size_);

  //          0 1 ... mid ... size size+1
  //                   ↓
  // 0 1 ... mid-1 && mid && mid+1 ... size+1
  auto mid_index = temp_internal_node_ptr->GetSize() / 2;
  auto mid_key = temp_internal_node_ptr->KeyAt(mid_index);
  new_internal_page_ptr->InitTwoChild(temp_internal_node_ptr->KeyAt(mid_index + 1),
                                      temp_internal_node_ptr->ValueAt(mid_index),
                                      temp_internal_node_ptr->ValueAt(mid_index + 1));
  new_internal_page_ptr->CopyFrom(temp_internal_node_ptr, 2, mid_index + 2,
                                  temp_internal_node_ptr->GetSize() - mid_index - 2);
  internal_page_ptr->SetSize(0);
  internal_page_ptr->CopyFrom(temp_internal_node_ptr, 0, mid_index);

  // free temp memory
  free(temp_internal_node_ptr);
  if (ctx.IsRootPage(cur_page_id)) {
    this->StartNewRoot(ctx, mid_key, cur_page_id, new_page_id);
    return;
  }
  // update parent node
  this->InsertAndSplitInternal(ctx, mid_key, new_page_id);
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/*
 * Delete key & value pair associated with input key
 * If current tree is empty, return immediately.
 * If not, User needs to first find the right leaf page as deletion target, then
 * delete entry from leaf page. Remember to deal with redistribute or merge if
 * necessary.
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Remove(const KeyType &key, Transaction *txn) {
  if (this->header_page_id_ == INVALID_PAGE_ID) {
    return;
  }

  // Declaration of context instance.
  Context ctx;
  ctx.header_page_ = this->bpm_->FetchPageWrite(this->header_page_id_);
  auto temp_page_ptr = ctx.header_page_->As<BPlusTreeHeaderPage>();
  ctx.root_page_id_ = temp_page_ptr->root_page_id_;
  if (ctx.root_page_id_ == INVALID_PAGE_ID) {
    this->ReleaseContext(ctx);
    return;
  }
  // search
  Get2LeafnodeWrite(ctx, ctx.root_page_id_, key, false);
  // reach leaf node
  auto node_page_ptr = ctx.write_set_.back().AsMut<BPlusTreePage>();
  auto leaf_page_ptr = reinterpret_cast<LeafPage *>(node_page_ptr);
  auto i = leaf_page_ptr->SearchKey(key, this->comparator_);
  // key doesn't exist
  if (i < 0 || this->comparator_(key, leaf_page_ptr->KeyAt(i)) != 0) {
    this->ReleaseContext(ctx);
    return;
  }
  // remove key-value
  this->RemoveAndMergeLeaf(ctx, i);
  // release context
  this->ReleaseContext(ctx);
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::RemoveAndMergeLeaf(Context &ctx, int index) {
  if (ctx.write_set_.empty()) {
    return;
  }
  auto cur_guard = std::move(ctx.write_set_.back());
  ctx.write_set_.pop_back();
  auto node_page_ptr = cur_guard.AsMut<BPlusTreePage>();
  // leaf node
  auto leaf_page_ptr = reinterpret_cast<LeafPage *>(node_page_ptr);
  // remove
  leaf_page_ptr->RemoveKV(index);
  // underflow is solved
  if (leaf_page_ptr->GetSize() >= leaf_page_ptr->GetMinSize()) {
    return;
  }
  // current node is root node
  if (ctx.IsRootPage(cur_guard.PageId())) {
    if (node_page_ptr->GetSize() == 0) {
      auto header_page = ctx.header_page_->AsMut<BPlusTreeHeaderPage>();
      header_page->root_page_id_ = INVALID_PAGE_ID;
      ctx.root_page_id_ = INVALID_PAGE_ID;
    }
    return;
  }

  auto parent_page_ptr = ctx.write_set_.back().AsMut<InternalPage>();
  auto cur_index = parent_page_ptr->ValueIndex(cur_guard.PageId());
  if (cur_index == -1) {
    throw Exception("value index illegal");
  }
  // redistribute
  if (cur_index > 0) {
    WritePageGuard left_leaf_page_guard = this->bpm_->FetchPageWrite(parent_page_ptr->ValueAt(cur_index - 1));
    auto left_leaf_page_ptr = left_leaf_page_guard.AsMut<LeafPage>();
    if (left_leaf_page_ptr->GetSize() > left_leaf_page_ptr->GetMinSize()) {
      auto move_key = left_leaf_page_ptr->KeyAt(left_leaf_page_ptr->GetSize() - 1);
      auto move_value = left_leaf_page_ptr->ValueAt(left_leaf_page_ptr->GetSize() - 1);
      leaf_page_ptr->InsertKV(move_key, move_value, this->comparator_);
      left_leaf_page_ptr->DecreaseSize(1);
      // update parent
      parent_page_ptr->SetKeyAt(cur_index, move_key);
      return;
    }
    left_leaf_page_guard.Drop();
  }
  if (cur_index < parent_page_ptr->GetSize() - 1) {
    WritePageGuard right_leaf_page_guard = this->bpm_->FetchPageWrite(parent_page_ptr->ValueAt(cur_index + 1));
    auto right_leaf_page_ptr = right_leaf_page_guard.AsMut<LeafPage>();
    if (right_leaf_page_ptr->GetSize() > right_leaf_page_ptr->GetMinSize()) {
      auto move_key = right_leaf_page_ptr->KeyAt(0);
      auto move_value = right_leaf_page_ptr->ValueAt(0);
      leaf_page_ptr->InsertKV(move_key, move_value, this->comparator_);
      right_leaf_page_ptr->RemoveKV(0);
      // update parent
      parent_page_ptr->SetKeyAt(cur_index + 1, right_leaf_page_ptr->KeyAt(0));
      return;
    }
    right_leaf_page_guard.Drop();
  }
  // coalesces
  if (cur_index > 0) {
    // left
    WritePageGuard left_leaf_page_guard = this->bpm_->FetchPageWrite(parent_page_ptr->ValueAt(cur_index - 1));
    auto left_leaf_page_ptr = left_leaf_page_guard.AsMut<LeafPage>();
    left_leaf_page_ptr->CopyTo(leaf_page_ptr, left_leaf_page_ptr->GetSize());
    left_leaf_page_ptr->SetNextPageId(leaf_page_ptr->GetNextPageId());
    // clear another node
    auto leaf_page_id = cur_guard.PageId();
    cur_guard.Drop();
    left_leaf_page_guard.Drop();
    this->bpm_->DeletePage(leaf_page_id);
    // update parent
    this->RemoveAndMergeInternal(ctx, cur_index);
  } else {
    // right
    WritePageGuard right_leaf_page_guard = this->bpm_->FetchPageWrite(parent_page_ptr->ValueAt(cur_index + 1));
    auto right_leaf_page_ptr = right_leaf_page_guard.AsMut<LeafPage>();
    leaf_page_ptr->CopyTo(right_leaf_page_ptr, leaf_page_ptr->GetSize());
    leaf_page_ptr->SetNextPageId(right_leaf_page_ptr->GetNextPageId());
    // clear empty one
    auto right_leaf_page_id = right_leaf_page_guard.PageId();
    cur_guard.Drop();
    right_leaf_page_guard.Drop();
    this->bpm_->DeletePage(right_leaf_page_id);
    // update parent
    this->RemoveAndMergeInternal(ctx, cur_index + 1);
  }
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::RemoveAndMergeInternal(Context &ctx, int index) {
  if (ctx.write_set_.empty()) {
    return;
  }
  auto cur_guard = std::move(ctx.write_set_.back());
  ctx.write_set_.pop_back();
  auto node_page_ptr = cur_guard.AsMut<BPlusTreePage>();
  // internal node
  auto internal_page_ptr = reinterpret_cast<InternalPage *>(node_page_ptr);
  // remove
  internal_page_ptr->RemoveKV(index);
  // underflow is solved
  if (internal_page_ptr->GetSize() >= internal_page_ptr->GetMinSize()) {
    return;
  }
  // current node is root node
  if (ctx.IsRootPage(cur_guard.PageId())) {
    if (internal_page_ptr->GetSize() < 2) {
      auto header_page_ptr = ctx.header_page_->AsMut<BPlusTreeHeaderPage>();
      header_page_ptr->root_page_id_ = internal_page_ptr->ValueAt(0);
      ctx.root_page_id_ = internal_page_ptr->ValueAt(0);
    }
    return;
  }

  auto parent_page_ptr = ctx.write_set_.back().AsMut<InternalPage>();
  auto cur_index = parent_page_ptr->ValueIndex(cur_guard.PageId());
  if (cur_index == -1) {
    throw Exception("value index illegal");
  }
  // redistribute
  if (cur_index > 0) {
    WritePageGuard left_internal_page_guard = this->bpm_->FetchPageWrite(parent_page_ptr->ValueAt(cur_index - 1));
    auto left_internal_page_ptr = left_internal_page_guard.AsMut<InternalPage>();
    if (left_internal_page_ptr->GetSize() > left_internal_page_ptr->GetMinSize()) {
      auto move_value = left_internal_page_ptr->ValueAt(left_internal_page_ptr->GetSize() - 1);
      auto move_key = this->GetFirstKey(internal_page_ptr->ValueAt(0));
      internal_page_ptr->InsertKV(move_key, internal_page_ptr->ValueAt(0), this->comparator_);
      internal_page_ptr->SetValueAt(0, move_value);
      left_internal_page_ptr->DecreaseSize(1);
      // update parent
      parent_page_ptr->SetKeyAt(cur_index, this->GetFirstKey(internal_page_ptr->ValueAt(0)));
      return;
    }
    left_internal_page_guard.Drop();
  }
  if (cur_index < parent_page_ptr->GetSize() - 1) {
    WritePageGuard right_internal_page_guard = this->bpm_->FetchPageWrite(parent_page_ptr->ValueAt(cur_index + 1));
    auto right_internal_page_ptr = right_internal_page_guard.AsMut<InternalPage>();
    if (right_internal_page_ptr->GetSize() > right_internal_page_ptr->GetMinSize()) {
      auto move_value = right_internal_page_ptr->ValueAt(0);
      auto move_key = this->GetFirstKey(move_value);
      internal_page_ptr->InsertKV(move_key, move_value, this->comparator_);
      right_internal_page_ptr->RemoveKV(0);
      // update parent
      parent_page_ptr->SetKeyAt(cur_index + 1, this->GetFirstKey(right_internal_page_ptr->ValueAt(0)));
      return;
    }
    right_internal_page_guard.Drop();
  }
  // coalesces
  if (cur_index > 0) {
    // left
    WritePageGuard left_internal_page_guard = this->bpm_->FetchPageWrite(parent_page_ptr->ValueAt(cur_index - 1));
    auto left_internal_page_ptr = left_internal_page_guard.AsMut<InternalPage>();
    left_internal_page_ptr->InsertKV(this->GetFirstKey(internal_page_ptr->ValueAt(0)), internal_page_ptr->ValueAt(0),
                                     this->comparator_);
    left_internal_page_ptr->CopyTo(internal_page_ptr, left_internal_page_ptr->GetSize());
    // clear emptry one
    auto internal_page_id = cur_guard.PageId();
    cur_guard.Drop();
    left_internal_page_guard.Drop();
    this->bpm_->DeletePage(internal_page_id);
    // update parent
    this->RemoveAndMergeInternal(ctx, cur_index);
  } else {
    // right
    WritePageGuard right_internal_page_guard = this->bpm_->FetchPageWrite(parent_page_ptr->ValueAt(cur_index + 1));
    auto right_internal_page_ptr = right_internal_page_guard.AsMut<InternalPage>();
    right_internal_page_ptr->InsertKV(this->GetFirstKey(right_internal_page_ptr->ValueAt(0)),
                                      right_internal_page_ptr->ValueAt(0), this->comparator_);
    internal_page_ptr->CopyTo(right_internal_page_ptr, internal_page_ptr->GetSize());
    // clear emptry one
    auto right_internal_page_id = right_internal_page_guard.PageId();
    cur_guard.Drop();
    right_internal_page_guard.Drop();
    this->bpm_->DeletePage(right_internal_page_id);
    // update parent
    this->RemoveAndMergeInternal(ctx, cur_index + 1);
  }
}

/*****************************************************************************
 * INDEX ITERATOR
 *****************************************************************************/
/*
 * Input parameter is void, find the leftmost leaf page first, then construct
 * index iterator
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin() -> INDEXITERATOR_TYPE {
  auto root_page_id = this->GetRootPageId();
  if (root_page_id == INVALID_PAGE_ID) {
    return this->End();
  }

  ReadPageGuard child_guard = this->bpm_->FetchPageRead(root_page_id);
  auto node_page_ptr = child_guard.As<BPlusTreePage>();
  // search in internal node
  while (!node_page_ptr->IsLeafPage()) {
    auto internal_page_ptr = reinterpret_cast<const InternalPage *>(node_page_ptr);
    auto page_id = internal_page_ptr->ValueAt(0);

    // drop and reassign
    child_guard = std::move(this->bpm_->FetchPageRead(page_id));
    node_page_ptr = child_guard.As<BPlusTreePage>();
  }

  auto page_id = child_guard.PageId();
  child_guard.Drop();
  return std::move(INDEXITERATOR_TYPE(this->bpm_, page_id, 0));
}

/*
 * Input parameter is low key, find the leaf page that contains the input key
 * first, then construct index iterator
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin(const KeyType &key) -> INDEXITERATOR_TYPE {
  auto root_page_id = this->GetRootPageId();
  if (root_page_id == INVALID_PAGE_ID) {
    return this->End();
  }
  Context ctx;
  ctx.root_page_id_ = root_page_id;
  this->Get2LeafnodeRead(ctx, ctx.root_page_id_, key);
  ReadPageGuard read_guard = std::move(ctx.read_set_.front());
  ctx.read_set_.pop_front();
  this->ReleaseContext(ctx);

  // reach leaf node
  auto leaf_page_ptr = read_guard.As<const LeafPage>();
  auto i = leaf_page_ptr->SearchKey(key, this->comparator_);
  if (this->comparator_(key, leaf_page_ptr->KeyAt(i)) == 0) {
    return std::move(INDEXITERATOR_TYPE(this->bpm_, read_guard.PageId(), i));
  }
  return this->End();
}

/*
 * Input parameter is void, construct an index iterator representing the end
 * of the key/value pair in the leaf node
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::End() -> INDEXITERATOR_TYPE { return INDEXITERATOR_TYPE(this->bpm_, INVALID_PAGE_ID, -1); }

/**
 * @return Page id of the root of this tree
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetRootPageId() const -> page_id_t {
  if (this->header_page_id_ == INVALID_PAGE_ID) {
    return INVALID_PAGE_ID;
  }
  ReadPageGuard page_read_guard = this->bpm_->FetchPageRead(this->header_page_id_);
  auto page_read_ptr = page_read_guard.As<BPlusTreeHeaderPage>();
  return page_read_ptr->root_page_id_;
}

/*****************************************************************************
 * UTILITIES AND DEBUG
 *****************************************************************************/

/*
 * This method is used for test only
 * Read data from file and insert one by one
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertFromFile(const std::string &file_name, Transaction *txn) {
  int64_t key;
  std::ifstream input(file_name);
  while (input) {
    input >> key;

    KeyType index_key;
    index_key.SetFromInteger(key);
    RID rid(key);
    Insert(index_key, rid, txn);
  }
}
/*
 * This method is used for test only
 * Read data from file and remove one by one
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::RemoveFromFile(const std::string &file_name, Transaction *txn) {
  int64_t key;
  std::ifstream input(file_name);
  while (input) {
    input >> key;
    KeyType index_key;
    index_key.SetFromInteger(key);
    Remove(index_key, txn);
  }
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Print(BufferPoolManager *bpm) {
  auto root_page_id = GetRootPageId();
  auto guard = bpm->FetchPageBasic(root_page_id);
  PrintTree(guard.PageId(), guard.template As<BPlusTreePage>());
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::PrintTree(page_id_t page_id, const BPlusTreePage *page) {
  if (page->IsLeafPage()) {
    auto *leaf = reinterpret_cast<const LeafPage *>(page);
    std::cout << "Leaf Page: " << page_id << "\tNext: " << leaf->GetNextPageId() << std::endl;

    // Print the contents of the leaf page.
    std::cout << "Contents: ";
    for (int i = 0; i < leaf->GetSize(); i++) {
      std::cout << leaf->KeyAt(i);
      if ((i + 1) < leaf->GetSize()) {
        std::cout << ", ";
      }
    }
    std::cout << std::endl;
    std::cout << std::endl;

  } else {
    auto *internal = reinterpret_cast<const InternalPage *>(page);
    std::cout << "Internal Page: " << page_id << std::endl;

    // Print the contents of the internal page.
    std::cout << "Contents: ";
    for (int i = 0; i < internal->GetSize(); i++) {
      std::cout << internal->KeyAt(i) << ": " << internal->ValueAt(i);
      if ((i + 1) < internal->GetSize()) {
        std::cout << ", ";
      }
    }
    std::cout << std::endl;
    std::cout << std::endl;
    for (int i = 0; i < internal->GetSize(); i++) {
      auto guard = bpm_->FetchPageBasic(internal->ValueAt(i));
      PrintTree(guard.PageId(), guard.template As<BPlusTreePage>());
    }
  }
}

/**
 * This method is used for debug only, You don't need to modify
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Draw(BufferPoolManager *bpm, const std::string &outf) {
  if (IsEmpty()) {
    LOG_WARN("Drawing an empty tree");
    return;
  }

  std::ofstream out(outf);
  out << "digraph G {" << std::endl;
  auto root_page_id = GetRootPageId();
  auto guard = bpm->FetchPageBasic(root_page_id);
  ToGraph(guard.PageId(), guard.template As<BPlusTreePage>(), out);
  out << "}" << std::endl;
  out.close();
}

/**
 * This method is used for debug only, You don't need to modify
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ToGraph(page_id_t page_id, const BPlusTreePage *page, std::ofstream &out) {
  std::string leaf_prefix("LEAF_");
  std::string internal_prefix("INT_");
  if (page->IsLeafPage()) {
    auto *leaf = reinterpret_cast<const LeafPage *>(page);
    // Print node name
    out << leaf_prefix << page_id;
    // Print node properties
    out << "[shape=plain color=green ";
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">P=" << page_id << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">"
        << "max_size=" << leaf->GetMaxSize() << ",min_size=" << leaf->GetMinSize() << ",size=" << leaf->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < leaf->GetSize(); i++) {
      out << "<TD>" << leaf->KeyAt(i) << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print Leaf node link if there is a next page
    if (leaf->GetNextPageId() != INVALID_PAGE_ID) {
      out << leaf_prefix << page_id << " -> " << leaf_prefix << leaf->GetNextPageId() << ";\n";
      out << "{rank=same " << leaf_prefix << page_id << " " << leaf_prefix << leaf->GetNextPageId() << "};\n";
    }
  } else {
    auto *inner = reinterpret_cast<const InternalPage *>(page);
    // Print node name
    out << internal_prefix << page_id;
    // Print node properties
    out << "[shape=plain color=pink ";  // why not?
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">P=" << page_id << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">"
        << "max_size=" << inner->GetMaxSize() << ",min_size=" << inner->GetMinSize() << ",size=" << inner->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < inner->GetSize(); i++) {
      out << "<TD PORT=\"p" << inner->ValueAt(i) << "\">";
      if (i > 0) {
        out << inner->KeyAt(i);
      } else {
        out << " ";
      }
      out << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print leaves
    for (int i = 0; i < inner->GetSize(); i++) {
      auto child_guard = bpm_->FetchPageBasic(inner->ValueAt(i));
      auto child_page = child_guard.template As<BPlusTreePage>();
      ToGraph(child_guard.PageId(), child_page, out);
      if (i > 0) {
        auto sibling_guard = bpm_->FetchPageBasic(inner->ValueAt(i - 1));
        auto sibling_page = sibling_guard.template As<BPlusTreePage>();
        if (!sibling_page->IsLeafPage() && !child_page->IsLeafPage()) {
          out << "{rank=same " << internal_prefix << sibling_guard.PageId() << " " << internal_prefix
              << child_guard.PageId() << "};\n";
        }
      }
      out << internal_prefix << page_id << ":p" << child_guard.PageId() << " -> ";
      if (child_page->IsLeafPage()) {
        out << leaf_prefix << child_guard.PageId() << ";\n";
      } else {
        out << internal_prefix << child_guard.PageId() << ";\n";
      }
    }
  }
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::DrawBPlusTree() -> std::string {
  if (IsEmpty()) {
    return "()";
  }

  PrintableBPlusTree p_root = ToPrintableBPlusTree(GetRootPageId());
  std::ostringstream out_buf;
  p_root.Print(out_buf);

  return out_buf.str();
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::ToPrintableBPlusTree(page_id_t root_id) -> PrintableBPlusTree {
  auto root_page_guard = bpm_->FetchPageBasic(root_id);
  auto root_page = root_page_guard.template As<BPlusTreePage>();
  PrintableBPlusTree proot;

  if (root_page->IsLeafPage()) {
    auto leaf_page = root_page_guard.template As<LeafPage>();
    proot.keys_ = leaf_page->ToString();
    proot.size_ = proot.keys_.size() + 4;  // 4 more spaces for indent

    return proot;
  }

  // draw internal page
  auto internal_page = root_page_guard.template As<InternalPage>();
  proot.keys_ = internal_page->ToString();
  proot.size_ = 0;
  for (int i = 0; i < internal_page->GetSize(); i++) {
    page_id_t child_id = internal_page->ValueAt(i);
    PrintableBPlusTree child_node = ToPrintableBPlusTree(child_id);
    proot.size_ += child_node.size_;
    proot.children_.push_back(child_node);
  }

  return proot;
}

template class BPlusTree<GenericKey<4>, RID, GenericComparator<4>>;

template class BPlusTree<GenericKey<8>, RID, GenericComparator<8>>;

template class BPlusTree<GenericKey<16>, RID, GenericComparator<16>>;

template class BPlusTree<GenericKey<32>, RID, GenericComparator<32>>;

template class BPlusTree<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
