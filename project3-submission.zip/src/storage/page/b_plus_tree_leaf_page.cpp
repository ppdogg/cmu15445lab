//===----------------------------------------------------------------------===//
//
//                         CMU-DB Project (15-445/645)
//                         ***DO NO SHARE PUBLICLY***
//
// Identification: src/page/b_plus_tree_leaf_page.cpp
//
// Copyright (c) 2018, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <algorithm>
#include <sstream>
#include <utility>

#include "common/config.h"
#include "common/exception.h"
#include "common/rid.h"
#include "storage/page/b_plus_tree_leaf_page.h"
#include "storage/page/b_plus_tree_page.h"
#include "storage/page/hash_table_page_defs.h"

namespace bustub {

/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/

/**
 * Init method after creating a new leaf page
 * Including set page type, set current size to zero, set next page id and set max size
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::Init(int max_size) {
  this->SetMaxSize(max_size);
  this->SetSize(0);
  this->SetPageType(IndexPageType::LEAF_PAGE);
  this->SetNextPageId(INVALID_PAGE_ID);
}

/**
 * Helper methods to set/get next page id
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_LEAF_PAGE_TYPE::GetNextPageId() const -> page_id_t { return this->next_page_id_; }

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::SetNextPageId(page_id_t next_page_id) { this->next_page_id_ = next_page_id; }

/*
 * Helper method to find and return the key associated with input "index"(a.k.a
 * array offset)
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_LEAF_PAGE_TYPE::KeyAt(int index) const -> KeyType {
  // replace with your own code
  if (index < 0 || index >= this->GetSize()) {
    return KeyType{};
  }
  return this->array_[index].first;
}

INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_LEAF_PAGE_TYPE::ValueAt(int index) const -> ValueType {
  if (index < 0 || index >= this->GetSize()) {
    return ValueType{};
  }
  return this->array_[index].second;
}

INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_LEAF_PAGE_TYPE::GetValue(int index) const -> const MappingType & {
  if (index < 0 || index >= this->GetSize()) {
    throw Exception("illegal index");
  }
  return this->array_[index];
}

INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_LEAF_PAGE_TYPE::SearchKey(const KeyType &key, const KeyComparator &comp) const -> int {
  // [-1, size-1]
  int index =
      std::upper_bound(array_, array_ + GetSize(), key,
                       [&](const KeyType &key, const MappingType &m) -> bool { return comp(key, m.first) < 0; }) -
      array_ - 1;
  return index;
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::InsertKV(const KeyType &key, const ValueType &value, const KeyComparator &comp) {
  auto i = this->SearchKey(key, comp);
  if (i >= 0 && comp(this->KeyAt(i), key) == 0) {
    return;
  }
  // [0, size]
  i++;
  for (int j = this->GetSize(); i < j; j--) {
    this->array_[j] = std::move(this->array_[j - 1]);
  }
  this->array_[i] = MappingType(std::move(key), std::move(value));
  this->IncreaseSize(1);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::RemoveKV(int index) {
  if (index < 0 || index >= this->GetSize()) {
    return;
  }
  for (int i = index; i < this->GetSize() - 1; i++) {
    this->array_[i] = std::move(this->array_[i + 1]);
  }
  this->array_[this->GetSize() - 1] = MappingType{};
  this->DecreaseSize(1);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::CopyFrom(const BPlusTreeLeafPage *other, int start, int length) {
  for (int i = 0; i < length; i++) {
    this->array_[i] = MappingType(std::move(other->KeyAt(i + start)), std::move(other->ValueAt(i + start)));
  }
  this->IncreaseSize(length);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::CopyFrom(const BPlusTreeLeafPage *other, int start) {
  this->CopyFrom(other, start, other->GetSize() - start);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::CopyTo(const BPlusTreeLeafPage *other, int start, int length) {
  for (int i = 0; i < length; i++) {
    this->array_[i + start] = MappingType(std::move(other->KeyAt(i)), std::move(other->ValueAt(i)));
  }
  this->IncreaseSize(length);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::CopyTo(const BPlusTreeLeafPage *other, int start) {
  this->CopyTo(other, start, other->GetSize());
}

template class BPlusTreeLeafPage<GenericKey<4>, RID, GenericComparator<4>>;
template class BPlusTreeLeafPage<GenericKey<8>, RID, GenericComparator<8>>;
template class BPlusTreeLeafPage<GenericKey<16>, RID, GenericComparator<16>>;
template class BPlusTreeLeafPage<GenericKey<32>, RID, GenericComparator<32>>;
template class BPlusTreeLeafPage<GenericKey<64>, RID, GenericComparator<64>>;
}  // namespace bustub
