//===----------------------------------------------------------------------===//
//
//                         CMU-DB Project (15-445/645)
//                         ***DO NO SHARE PUBLICLY***
//
// Identification: src/page/b_plus_tree_internal_page.cpp
//
// Copyright (c) 2018, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <algorithm>
#include <iostream>
#include <sstream>
#include <utility>

#include "common/exception.h"
#include "storage/page/b_plus_tree_internal_page.h"
#include "storage/page/b_plus_tree_page.h"

namespace bustub {
/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/
/*
 * Init method after creating a new internal page
 * Including set page type, set current size, and set max page size
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::Init(int max_size) {
  this->SetMaxSize(max_size);
  this->SetSize(0);
  this->SetPageType(IndexPageType::INTERNAL_PAGE);
}
/*
 * Helper method to get/set the key associated with input "index"(a.k.a
 * array offset)
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::KeyAt(int index) const -> KeyType {
  // replace with your own code
  if (index <= 0 || index >= this->GetSize()) {
    return KeyType{};
  }
  return this->array_[index].first;
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::SetKeyAt(int index, const KeyType &key) {
  if (index < 0 && index >= this->GetSize()) {
    return;
  }
  this->array_[index].first = key;
}

INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::ValueIndex(const ValueType &value) const -> int {
  for (int i = 0; i < this->GetSize(); i++) {
    if (this->array_[i].second == value) {
      return i;
    }
  }
  return -1;
}

/*
 * Helper method to get the value associated with input "index"(a.k.a array
 * offset)
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::ValueAt(int index) const -> ValueType {
  if (index < 0 || index >= this->GetSize()) {
    return ValueType{};
  }
  return this->array_[index].second;
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::SetValueAt(int index, const ValueType &value) {
  if (index < 0 || index >= this->GetSize()) {
    return;
  }
  this->array_[index].second = value;
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::InitTwoChild(const KeyType &key, const ValueType &value1,
                                                  const ValueType &value2) {
  // the first key is illegal
  this->array_[0] = MappingType(KeyType{}, value1);
  this->array_[1] = MappingType(key, value2);
  this->IncreaseSize(2);
}

INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::SearchKey(const KeyType &key, const KeyComparator &comp) const -> int {
  // [0, size-1]
  int index =
      std::upper_bound(array_ + 1, array_ + GetSize(), key,
                       [&](const KeyType &key, const MappingType &m) -> bool { return comp(key, m.first) < 0; }) -
      array_ - 1;
  return index;
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::InsertKV(const KeyType &key, const ValueType &value, const KeyComparator &comp) {
  auto i = this->SearchKey(key, comp);
  if (i > 0 && comp(this->KeyAt(i), key) == 0) {
    return;
  }
  // [1, size]
  i++;
  for (int j = this->GetSize(); i < j; j--) {
    this->array_[j] = std::move(this->array_[j - 1]);
  }
  this->array_[i] = MappingType(std::move(key), std::move(value));
  this->IncreaseSize(1);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::RemoveKV(int index) {
  if (index < 0 || index >= this->GetSize()) {
    return;
  }
  for (int i = index; i < this->GetSize() - 1; i++) {
    this->array_[i] = std::move(this->array_[i + 1]);
  }
  this->array_[this->GetSize() - 1] = MappingType{};
  this->DecreaseSize(1);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::CopyFrom(const BPlusTreeInternalPage *other, int dst_s, int src_s, int length) {
  for (int i = 0; i < length; i++) {
    this->array_[i + dst_s] = MappingType(std::move(other->KeyAt(i + src_s)), std::move(other->ValueAt(i + src_s)));
  }
  this->IncreaseSize(length);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::CopyFrom(const BPlusTreeInternalPage *other, int start, int length) {
  for (int i = 0; i < length; i++) {
    this->array_[i] = MappingType(std::move(other->KeyAt(i + start)), std::move(other->ValueAt(i + start)));
  }
  this->IncreaseSize(length);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::CopyFrom(const BPlusTreeInternalPage *other, int start) {
  this->CopyFrom(other, start, other->GetSize() - start);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::CopyTo(const BPlusTreeInternalPage *other, int start, int length) {
  for (int i = 0; i < length; i++) {
    this->array_[i + start] = MappingType(std::move(other->KeyAt(i + 1)), std::move(other->ValueAt(i + 1)));
  }
  this->IncreaseSize(length);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::CopyTo(const BPlusTreeInternalPage *other, int start) {
  this->CopyTo(other, start, other->GetSize() - 1);
}

// valuetype for internalNode should be page id_t
template class BPlusTreeInternalPage<GenericKey<4>, page_id_t, GenericComparator<4>>;
template class BPlusTreeInternalPage<GenericKey<8>, page_id_t, GenericComparator<8>>;
template class BPlusTreeInternalPage<GenericKey<16>, page_id_t, GenericComparator<16>>;
template class BPlusTreeInternalPage<GenericKey<32>, page_id_t, GenericComparator<32>>;
template class BPlusTreeInternalPage<GenericKey<64>, page_id_t, GenericComparator<64>>;
}  // namespace bustub
