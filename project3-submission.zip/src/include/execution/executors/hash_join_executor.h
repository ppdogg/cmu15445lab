//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// hash_join_executor.h
//
// Identification: src/include/execution/executors/hash_join_executor.h
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <memory>
#include <unordered_map>
#include <utility>
#include <vector>

#include "execution/executor_context.h"
#include "execution/executors/abstract_executor.h"
#include "execution/executors/aggregation_executor.h"
#include "execution/expressions/abstract_expression.h"
#include "execution/plans/hash_join_plan.h"
#include "storage/table/tuple.h"
#include "type/value.h"

namespace bustub {
/** JoinKey represents the key of the join expression */
struct JoinKey {
  /** The aggregate values */
  // std::vector<bustub::Value> key_;
  Value val_;
  auto operator==(const JoinKey &other) const -> bool { return val_.CompareEquals(other.val_) == CmpBool::CmpTrue; }
  auto operator!=(const JoinKey &other) const -> bool { return !(*this == other); }
};
}  // namespace bustub
namespace std {
/** Implements std::hash on AggregateKey */
template <>
struct hash<bustub::JoinKey> {
  auto operator()(const bustub::JoinKey &join_key) const -> std::size_t {
    size_t curr_hash = 0;
    if (!join_key.val_.IsNull()) {
      curr_hash = bustub::HashUtil::CombineHashes(curr_hash, bustub::HashUtil::HashValue(&join_key.val_));
    }
    return curr_hash;
  }
};

}  // namespace std
namespace bustub {

class SimpleJoinHashTable {
 public:
  // SimpleJoinHashTable() = default;
  /**
   * Insert a key-value pair
   */
  void Set(const JoinKey &key, const Tuple &val) { this->ht_.insert({key, val}); }
  /**
   * Get the value of given key
   */
  auto Get(const JoinKey &key) -> std::vector<Tuple> {
    std::vector<Tuple> res{};
    auto scope = this->ht_.equal_range(key);
    for (auto it = scope.first; it != scope.second; ++it) {
      res.emplace_back(it->second);
    }
    return res;
  }
  /**
   * Clear the hash table
   */
  void Clear() { ht_.clear(); }

 private:
  std::unordered_multimap<JoinKey, Tuple> ht_;
};

/**
 * HashJoinExecutor executes a nested-loop JOIN on two tables.
 */
class HashJoinExecutor : public AbstractExecutor {
 public:
  /**
   * Construct a new HashJoinExecutor instance.
   * @param exec_ctx The executor context
   * @param plan The HashJoin join plan to be executed
   * @param left_child The child executor that produces tuples for the left side of join
   * @param right_child The child executor that produces tuples for the right side of join
   */
  HashJoinExecutor(ExecutorContext *exec_ctx, const HashJoinPlanNode *plan,
                   std::unique_ptr<AbstractExecutor> &&left_child, std::unique_ptr<AbstractExecutor> &&right_child);

  /** Initialize the join */
  void Init() override;

  /**
   * Yield the next tuple from the join.
   * @param[out] tuple The next tuple produced by the join.
   * @param[out] rid The next tuple RID, not used by hash join.
   * @return `true` if a tuple was produced, `false` if there are no more tuples.
   */
  auto Next(Tuple *tuple, RID *rid) -> bool override;

  /** @return The output schema for the join */
  auto GetOutputSchema() const -> const Schema & override { return plan_->OutputSchema(); };

 private:
  auto MakeJoinKey(const Tuple *tuple, const AbstractExpressionRef &expr, const Schema &schema) -> JoinKey {
    return {expr->Evaluate(tuple, schema)};
  }

  void SimpleJoin();
  void LogicJoin();

 private:
  /** The NestedLoopJoin plan node to be executed. */
  const HashJoinPlanNode *plan_;
  /** The child executor that produces tuples over which the aggregation is computed */
  std::unique_ptr<AbstractExecutor> left_child_;
  std::unique_ptr<AbstractExecutor> right_child_;

  SimpleJoinHashTable aht_;
  // SimpleJoinHashTable bht_;
  std::vector<Tuple> result_{};
  size_t cursor_{0};
};

}  // namespace bustub
