//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// hash_join_executor.cpp
//
// Identification: src/execution/hash_join_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/hash_join_executor.h"
#include <vector>
#include "common/rid.h"
#include "execution/expressions/abstract_expression.h"
#include "storage/table/tuple.h"
#include "type/value.h"

namespace bustub {

HashJoinExecutor::HashJoinExecutor(ExecutorContext *exec_ctx, const HashJoinPlanNode *plan,
                                   std::unique_ptr<AbstractExecutor> &&left_child,
                                   std::unique_ptr<AbstractExecutor> &&right_child)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      left_child_(std::move(left_child)),
      right_child_(std::move(right_child)) {
  if (plan->GetJoinType() != JoinType::LEFT && plan->GetJoinType() != JoinType::INNER) {
    // Note for 2023 Spring: You ONLY need to implement left join and inner join.
    throw bustub::NotImplementedException(fmt::format("join type {} not supported", plan->GetJoinType()));
  }
}

void HashJoinExecutor::SimpleJoin() {
  auto left_left_predict = this->plan_->LeftJoinKeyExpressions()[0];
  auto left_right_predict = this->plan_->RightJoinKeyExpressions()[0];

  std::vector<Tuple> left_tuples{};

  bool status;
  Tuple tuple{};
  RID rid{};

  status = left_child_->Next(&tuple, &rid);
  while (status) {
    left_tuples.emplace_back(tuple);
    status = left_child_->Next(&tuple, &rid);
  }

  status = right_child_->Next(&tuple, &rid);
  while (status) {
    this->aht_.Set(this->MakeJoinKey(&tuple, left_right_predict, right_child_->GetOutputSchema()), tuple);
    status = right_child_->Next(&tuple, &rid);
  }

  switch (this->plan_->GetJoinType()) {
    case JoinType::LEFT: {
      for (const auto &lt : left_tuples) {
        std::vector<Value> val;
        for (size_t i = 0; i < left_child_->GetOutputSchema().GetColumnCount(); i++) {
          val.emplace_back(lt.GetValue(&left_child_->GetOutputSchema(), i));
        }
        auto left_join_key = this->MakeJoinKey(&lt, left_left_predict, left_child_->GetOutputSchema());
        auto right_tuples = this->aht_.Get(left_join_key);

        bool is_match = false;
        for (const auto &rt : right_tuples) {
          auto right_join_key = this->MakeJoinKey(&rt, left_right_predict, right_child_->GetOutputSchema());
          if (left_join_key != right_join_key) {
            continue;
          }
          std::vector<Value> val_copy(val.begin(), val.end());
          for (size_t i = 0; i < right_child_->GetOutputSchema().GetColumnCount(); i++) {
            val_copy.emplace_back(rt.GetValue(&right_child_->GetOutputSchema(), i));
          }
          this->result_.emplace_back(val_copy, &this->plan_->OutputSchema());
          is_match = true;
        }

        if (!is_match) {
          for (size_t i = 0; i < right_child_->GetOutputSchema().GetColumnCount(); i++) {
            val.emplace_back(ValueFactory::GetNullValueByType(right_child_->GetOutputSchema().GetColumn(i).GetType()));
          }
          this->result_.emplace_back(val, &this->plan_->OutputSchema());
        }
      }
    } break;
    case JoinType::INNER: {
      for (const auto &lt : left_tuples) {
        std::vector<Value> val;
        for (size_t i = 0; i < left_child_->GetOutputSchema().GetColumnCount(); i++) {
          val.emplace_back(lt.GetValue(&left_child_->GetOutputSchema(), i));
        }
        auto left_join_key = this->MakeJoinKey(&lt, left_left_predict, left_child_->GetOutputSchema());
        auto right_tuples = this->aht_.Get(left_join_key);

        for (const auto &rt : right_tuples) {
          auto right_join_key = this->MakeJoinKey(&rt, left_right_predict, right_child_->GetOutputSchema());
          if (left_join_key != right_join_key) {
            continue;
          }
          std::vector<Value> val_copy(val.begin(), val.end());
          for (size_t i = 0; i < right_child_->GetOutputSchema().GetColumnCount(); i++) {
            val_copy.emplace_back(rt.GetValue(&right_child_->GetOutputSchema(), i));
          }
          this->result_.emplace_back(val_copy, &this->plan_->OutputSchema());
        }
      }
    } break;
    case JoinType::RIGHT:
    case JoinType::OUTER:
    case JoinType::INVALID:
      break;
  }
}

void HashJoinExecutor::LogicJoin() {
  auto left_left_predict = this->plan_->LeftJoinKeyExpressions()[0];
  auto right_left_predict = this->plan_->LeftJoinKeyExpressions()[1];
  auto left_right_predict = this->plan_->RightJoinKeyExpressions()[0];
  auto right_right_predict = this->plan_->RightJoinKeyExpressions()[1];

  std::vector<Tuple> left_tuples{};
  // std::vector<Tuple> right_tuples{};

  bool status;
  Tuple tuple{};
  RID rid{};

  status = left_child_->Next(&tuple, &rid);
  while (status) {
    left_tuples.emplace_back(tuple);
    status = left_child_->Next(&tuple, &rid);
  }

  status = right_child_->Next(&tuple, &rid);
  while (status) {
    // right_tuples.emplace_back(tuple);
    this->aht_.Set(this->MakeJoinKey(&tuple, left_right_predict, right_child_->GetOutputSchema()), tuple);
    // this->bht_.Set(this->MakeJoinKey(&tuple, right_right_predict, right_child_->GetOutputSchema()), tuple);
    status = right_child_->Next(&tuple, &rid);
  }

  switch (this->plan_->GetJoinType()) {
    case JoinType::LEFT: {
      for (const auto &lt : left_tuples) {
        std::vector<Value> val;
        for (size_t i = 0; i < left_child_->GetOutputSchema().GetColumnCount(); i++) {
          val.emplace_back(lt.GetValue(&left_child_->GetOutputSchema(), i));
        }
        auto left_join_key = this->MakeJoinKey(&lt, left_left_predict, left_child_->GetOutputSchema());
        auto right_tuples = this->aht_.Get(left_join_key);

        std::vector<Tuple> match_tuples{};
        for (const auto &rt : right_tuples) {
          auto right_join_key = this->MakeJoinKey(&rt, left_right_predict, right_child_->GetOutputSchema());
          if (left_join_key == right_join_key) {
            match_tuples.emplace_back(rt);
          }
        }

        bool is_match = false;
        left_join_key = this->MakeJoinKey(&lt, right_left_predict, left_child_->GetOutputSchema());
        for (const auto &rt : match_tuples) {
          auto right_join_key = this->MakeJoinKey(&rt, right_right_predict, right_child_->GetOutputSchema());
          if (left_join_key != right_join_key) {
            continue;
          }
          std::vector<Value> val_copy(val.begin(), val.end());
          for (size_t i = 0; i < right_child_->GetOutputSchema().GetColumnCount(); i++) {
            val_copy.emplace_back(rt.GetValue(&right_child_->GetOutputSchema(), i));
          }
          this->result_.emplace_back(val_copy, &this->plan_->OutputSchema());
          is_match = true;
        }

        if (!is_match) {
          for (size_t i = 0; i < right_child_->GetOutputSchema().GetColumnCount(); i++) {
            val.emplace_back(ValueFactory::GetNullValueByType(right_child_->GetOutputSchema().GetColumn(i).GetType()));
          }
          this->result_.emplace_back(val, &this->plan_->OutputSchema());
        }
      }
    } break;
    case JoinType::INNER: {
      for (const auto &lt : left_tuples) {
        std::vector<Value> val;
        for (size_t i = 0; i < left_child_->GetOutputSchema().GetColumnCount(); i++) {
          val.emplace_back(lt.GetValue(&left_child_->GetOutputSchema(), i));
        }
        auto left_join_key = this->MakeJoinKey(&lt, left_left_predict, left_child_->GetOutputSchema());
        auto right_tuples = this->aht_.Get(left_join_key);

        std::vector<Tuple> match_tuples{};
        for (const auto &rt : right_tuples) {
          auto right_join_key = this->MakeJoinKey(&rt, left_right_predict, right_child_->GetOutputSchema());
          if (left_join_key == right_join_key) {
            match_tuples.emplace_back(rt);
          }
        }

        left_join_key = this->MakeJoinKey(&lt, right_left_predict, left_child_->GetOutputSchema());
        for (const auto &rt : match_tuples) {
          auto right_join_key = this->MakeJoinKey(&rt, right_right_predict, right_child_->GetOutputSchema());
          if (left_join_key != right_join_key) {
            continue;
          }
          std::vector<Value> val_copy(val.begin(), val.end());
          for (size_t i = 0; i < right_child_->GetOutputSchema().GetColumnCount(); i++) {
            val_copy.emplace_back(rt.GetValue(&right_child_->GetOutputSchema(), i));
          }
          this->result_.emplace_back(val_copy, &this->plan_->OutputSchema());
        }
      }
    } break;
    case JoinType::RIGHT:
    case JoinType::OUTER:
    case JoinType::INVALID:
      break;
  }
}

void HashJoinExecutor::Init() {
  left_child_->Init();
  right_child_->Init();
  this->aht_.Clear();
  cursor_ = 0;

  if (this->plan_->LeftJoinKeyExpressions().size() == 1 && this->plan_->RightJoinKeyExpressions().size() == 1) {
    SimpleJoin();
  } else if (this->plan_->LeftJoinKeyExpressions().size() == 2 && this->plan_->RightJoinKeyExpressions().size() == 2) {
    LogicJoin();
  }
}

auto HashJoinExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (this->cursor_ >= this->result_.size()) {
    return false;
  }
  *tuple = this->result_[this->cursor_];
  this->cursor_++;
  return true;
}

}  // namespace bustub
