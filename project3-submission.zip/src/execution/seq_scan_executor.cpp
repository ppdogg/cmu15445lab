//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// seq_scan_executor.cpp
//
// Identification: src/execution/seq_scan_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/seq_scan_executor.h"
#include <memory>
#include "common/exception.h"
#include "concurrency/lock_manager.h"
#include "concurrency/transaction.h"
#include "storage/table/table_iterator.h"

namespace bustub {

SeqScanExecutor::SeqScanExecutor(ExecutorContext *exec_ctx, const SeqScanPlanNode *plan)
    : AbstractExecutor(exec_ctx), plan_(plan) {}

void SeqScanExecutor::Init() {
  auto txn = this->GetExecutorContext()->GetTransaction();
  switch (txn->GetIsolationLevel()) {
    case IsolationLevel::REPEATABLE_READ:
      if (this->GetExecutorContext()->IsDelete()) {
        try {
          if (!this->GetExecutorContext()->GetLockManager()->LockTable(txn, LockManager::LockMode::INTENTION_EXCLUSIVE,
                                                                       this->plan_->GetTableOid())) {
            throw ExecutionException("seqscan lock table failed");
          }
        } catch (TransactionAbortException) {
          throw ExecutionException("seqscan lock table failed: transaction aborted");
        }

      } else {
        if (txn->GetExclusiveTableLockSet()->count(this->plan_->GetTableOid()) == 0) {
          try {
            if (!this->GetExecutorContext()->GetLockManager()->LockTable(txn, LockManager::LockMode::INTENTION_SHARED,
                                                                         this->plan_->GetTableOid())) {
              throw ExecutionException("seqscan lock table failed");
            }
          } catch (TransactionAbortException) {
            throw ExecutionException("seqscan lock table failed: transaction aborted");
          }
        }
      }
      break;
    case IsolationLevel::READ_COMMITTED:
    case IsolationLevel::READ_UNCOMMITTED:
      break;
  }
  this->cur_table_ = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
  this->cur_table_iter_ = std::make_unique<TableIterator>(this->cur_table_->table_->MakeEagerIterator());
}

auto SeqScanExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (this->cur_table_iter_->IsEnd()) {
    return false;
  }
  auto txn = this->GetExecutorContext()->GetTransaction();
  std::pair<TupleMeta, Tuple> tuple_pair;
  do {
    switch (txn->GetIsolationLevel()) {
      case IsolationLevel::REPEATABLE_READ:
      case IsolationLevel::READ_COMMITTED:
        if (this->GetExecutorContext()->IsDelete()) {
          try {
            if (!this->GetExecutorContext()->GetLockManager()->LockRow(
                    txn, LockManager::LockMode::EXCLUSIVE, cur_table_->oid_, this->cur_table_iter_->GetRID())) {
              throw ExecutionException("seqscan lock row failed");
            }
          } catch (TransactionAbortException) {
            throw ExecutionException("seqscan lock row failed: transaction aborted");
          }

        } else {
          if (txn->GetExclusiveRowLockSet()->at(cur_table_->oid_).count(this->cur_table_iter_->GetRID()) == 0) {
            try {
              if (!this->GetExecutorContext()->GetLockManager()->LockRow(
                      txn, LockManager::LockMode::SHARED, cur_table_->oid_, this->cur_table_iter_->GetRID())) {
                throw ExecutionException("seqscan lock row failed");
              }
            } catch (TransactionAbortException) {
              throw ExecutionException("seqscan lock row failed: transaction aborted");
            }
          }
        }
        break;
      case IsolationLevel::READ_UNCOMMITTED:
        break;
    }
    tuple_pair = this->cur_table_iter_->GetTuple();
    *tuple = tuple_pair.second;
    *rid = this->cur_table_iter_->GetRID();
    ++(*this->cur_table_iter_);

    if (tuple_pair.first.is_deleted_ || txn->GetIsolationLevel() == IsolationLevel::READ_COMMITTED) {
      this->GetExecutorContext()->GetLockManager()->UnlockRow(txn, cur_table_->oid_, *rid);
    }
  } while (!this->cur_table_iter_->IsEnd() && tuple_pair.first.is_deleted_);

  return !tuple_pair.first.is_deleted_;
}

}  // namespace bustub
