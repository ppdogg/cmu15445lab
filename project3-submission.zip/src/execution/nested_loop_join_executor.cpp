//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// nested_loop_join_executor.cpp
//
// Identification: src/execution/nested_loop_join_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/nested_loop_join_executor.h"
#include <cstddef>
#include <utility>
#include "binder/table_ref/bound_join_ref.h"
#include "common/exception.h"
#include "common/rid.h"
#include "storage/table/tuple.h"
#include "type/type_id.h"
#include "type/value_factory.h"

namespace bustub {

NestedLoopJoinExecutor::NestedLoopJoinExecutor(ExecutorContext *exec_ctx, const NestedLoopJoinPlanNode *plan,
                                               std::unique_ptr<AbstractExecutor> &&left_executor,
                                               std::unique_ptr<AbstractExecutor> &&right_executor)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      left_child_(std::move(left_executor)),
      right_child_(std::move(right_executor)) {
  if (plan->GetJoinType() != JoinType::LEFT && plan->GetJoinType() != JoinType::INNER) {
    // Note for 2023 Spring: You ONLY need to implement left join and inner join.
    throw bustub::NotImplementedException(fmt::format("join type {} not supported", plan->GetJoinType()));
  }
}

void NestedLoopJoinExecutor::Init() {
  left_child_->Init();
  // right_child_->Init();

  std::vector<Tuple> left_tuples{};
  std::vector<Tuple> right_tuples{};

  bool status;
  Tuple l_tuple{};
  Tuple r_tuple{};
  RID rid{};

  status = left_child_->Next(&l_tuple, &rid);
  while (status) {
    left_tuples.emplace_back(l_tuple);
    right_child_->Init();
    right_tuples.clear();
    auto stat = right_child_->Next(&r_tuple, &rid);
    while (stat) {
      right_tuples.emplace_back(r_tuple);
      stat = right_child_->Next(&r_tuple, &rid);
    }
    status = left_child_->Next(&l_tuple, &rid);
  }

  auto filter_expr = plan_->Predicate();
  switch (this->plan_->GetJoinType()) {
    case JoinType::LEFT: {
      for (const auto &lt : left_tuples) {
        std::vector<Value> val;
        for (size_t i = 0; i < left_child_->GetOutputSchema().GetColumnCount(); i++) {
          val.emplace_back(lt.GetValue(&left_child_->GetOutputSchema(), i));
        }
        bool match = false;
        for (const auto &rt : right_tuples) {
          auto join_res = filter_expr->EvaluateJoin(&lt, this->left_child_->GetOutputSchema(), &rt,
                                                    this->right_child_->GetOutputSchema());
          if (!join_res.IsNull() && join_res.GetAs<bool>()) {
            std::vector<Value> val_copy(val.begin(), val.end());
            for (size_t i = 0; i < right_child_->GetOutputSchema().GetColumnCount(); i++) {
              val_copy.emplace_back(rt.GetValue(&right_child_->GetOutputSchema(), i));
            }
            match = true;
            this->result_.emplace_back(val_copy, &this->plan_->OutputSchema());
          }
        }
        if (!match) {
          for (size_t i = 0; i < right_child_->GetOutputSchema().GetColumnCount(); i++) {
            val.emplace_back(ValueFactory::GetNullValueByType(right_child_->GetOutputSchema().GetColumn(i).GetType()));
          }
          this->result_.emplace_back(val, &this->plan_->OutputSchema());
        }
      }
    } break;
    case JoinType::INNER: {
      for (const auto &lt : left_tuples) {
        std::vector<Value> val;
        for (size_t i = 0; i < left_child_->GetOutputSchema().GetColumnCount(); i++) {
          val.emplace_back(lt.GetValue(&left_child_->GetOutputSchema(), i));
        }
        for (const auto &rt : right_tuples) {
          auto join_res = filter_expr->EvaluateJoin(&lt, this->left_child_->GetOutputSchema(), &rt,
                                                    this->right_child_->GetOutputSchema());
          if (!join_res.IsNull() && join_res.GetAs<bool>()) {
            std::vector<Value> val_copy(val.begin(), val.end());
            for (size_t i = 0; i < right_child_->GetOutputSchema().GetColumnCount(); i++) {
              val_copy.emplace_back(rt.GetValue(&right_child_->GetOutputSchema(), i));
            }
            this->result_.emplace_back(val_copy, &this->plan_->OutputSchema());
          }
        }
      }
    } break;
    case JoinType::INVALID:
    case JoinType::RIGHT:
    case JoinType::OUTER:
      break;
  }
}

auto NestedLoopJoinExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (this->cursor_ >= this->result_.size()) {
    return false;
  }
  *tuple = this->result_[this->cursor_];
  this->cursor_++;
  return true;
}

}  // namespace bustub
