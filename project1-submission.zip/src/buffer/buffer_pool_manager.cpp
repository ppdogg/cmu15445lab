//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// buffer_pool_manager.cpp
//
// Identification: src/buffer/buffer_pool_manager.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/buffer_pool_manager.h"
#include <cstddef>
#include "common/config.h"
#include "common/exception.h"
#include "common/macros.h"
#include "storage/disk/disk_manager.h"
#include "storage/page/page.h"
#include "storage/page/page_guard.h"

namespace bustub {

BufferPoolManager::BufferPoolManager(size_t pool_size, DiskManager *disk_manager, size_t replacer_k,
                                     LogManager *log_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager), log_manager_(log_manager) {
  // TODO(students): remove this line after you have implemented the buffer pool manager
  // throw NotImplementedException(
  //     "BufferPoolManager is not implemented yet. If you have finished implementing BPM, please remove the throw "
  //     "exception line in `buffer_pool_manager.cpp`.");

  // we allocate a consecutive memory space for the buffer pool
  pages_ = new Page[pool_size_];
  replacer_ = std::make_unique<LRUKReplacer>(pool_size, replacer_k);

  // Initially, every page is in the free list.
  for (size_t i = 0; i < pool_size_; ++i) {
    free_list_.emplace_back(static_cast<int>(i));
  }
}

BufferPoolManager::~BufferPoolManager() { delete[] pages_; }

auto BufferPoolManager::NewPage(page_id_t *page_id) -> Page * {
  std::scoped_lock<std::mutex> guard(this->latch_);

  if (this->free_list_.empty()) {
    if (this->replacer_->Size() == 0) {
      // no free frame and no evictable frame
      return nullptr;
    }
    // existing evictable frame
    frame_id_t frame_id;
    this->replacer_->Evict(&frame_id);
    this->free_list_.emplace_back(frame_id);
  }

  Page *p = nullptr;
  frame_id_t freeframe_id = this->free_list_.front();
  p = &this->pages_[freeframe_id];

  // write modified datafrom memory to disk
  if (p->IsDirty()) {
    this->disk_manager_->WritePage(p->page_id_, p->data_);
  }
  this->page_table_.erase(p->page_id_);

  // auto new_pid = AllocatePage();
  *page_id = AllocatePage();
  // reset page meta data
  p->ResetMemory();
  p->page_id_ = *page_id;
  p->pin_count_ = 1;
  p->is_dirty_ = false;

  // update replacer
  this->replacer_->RecordAccess(freeframe_id, AccessType::Unknown);
  this->replacer_->SetEvictable(freeframe_id, false);

  // update pool manager
  this->free_list_.pop_front();
  this->page_table_[*page_id] = freeframe_id;
  return p;
}

auto BufferPoolManager::FetchPage(page_id_t page_id, [[maybe_unused]] AccessType access_type) -> Page * {
  std::scoped_lock<std::mutex> guard(this->latch_);

  if (this->page_table_.count(page_id) != 0) {
    // already exists in memory
    auto frame_id = this->page_table_[page_id];
    Page *p = &this->pages_[frame_id];
    p->pin_count_++;

    this->replacer_->RecordAccess(frame_id, AccessType::Unknown);
    this->replacer_->SetEvictable(frame_id, false);
    return p;
  }

  if (this->free_list_.empty()) {
    if (this->replacer_->Size() == 0) {
      // no free frame and no evictable frame
      return nullptr;
    }
    // existing evictable frame
    frame_id_t frame_id;
    this->replacer_->Evict(&frame_id);
    this->free_list_.emplace_back(frame_id);
  }

  Page *p = nullptr;
  frame_id_t freeframe_id = this->free_list_.front();
  p = &this->pages_[freeframe_id];

  if (p->IsDirty()) {
    // write modified date from memory to disk
    this->disk_manager_->WritePage(p->page_id_, p->data_);
  }
  // reset meta data
  this->page_table_.erase(p->page_id_);

  // replace page
  p->ResetMemory();
  p->page_id_ = page_id;
  p->pin_count_ = 1;
  p->is_dirty_ = false;
  // read data from dist to page in memory
  this->disk_manager_->ReadPage(p->page_id_, p->data_);

  // update replacer
  this->replacer_->RecordAccess(freeframe_id, AccessType::Unknown);
  this->replacer_->SetEvictable(freeframe_id, false);

  // update pool manager
  this->free_list_.pop_front();
  this->page_table_[page_id] = freeframe_id;

  return p;
}

auto BufferPoolManager::UnpinPage(page_id_t page_id, bool is_dirty, [[maybe_unused]] AccessType access_type) -> bool {
  std::scoped_lock<std::mutex> guard(this->latch_);

  if (this->page_table_.count(page_id) == 0) {
    return false;
  }

  auto frame_id = this->page_table_[page_id];
  auto &p = this->pages_[frame_id];
  if (p.GetPinCount() <= 0) {
    return false;
  }

  if (!p.IsDirty()) {
    p.is_dirty_ = is_dirty;
  }
  if (--p.pin_count_ == 0) {
    this->replacer_->SetEvictable(frame_id, true);
  }

  return true;
}

auto BufferPoolManager::FlushPage(page_id_t page_id) -> bool {
  std::scoped_lock<std::mutex> guard(this->latch_);
  // page not in memory
  if (this->page_table_.count(page_id) == 0) {
    return false;
  }

  auto &p = this->pages_[this->page_table_.at(page_id)];
  this->disk_manager_->WritePage(p.page_id_, p.data_);
  p.is_dirty_ = false;

  return true;
}

void BufferPoolManager::FlushAllPages() {
  for (size_t i = 0; i < this->pool_size_; i++) {
    auto &p = this->pages_[i];
    if (p.page_id_ != INVALID_PAGE_ID) {
      FlushPage(p.page_id_);
    }
  }
}

auto BufferPoolManager::DeletePage(page_id_t page_id) -> bool {
  std::scoped_lock<std::mutex> guard(this->latch_);

  if (this->page_table_.count(page_id) == 0) {
    return true;
  }

  auto frame_id = this->page_table_.at(page_id);
  auto &p = this->pages_[frame_id];

  // the page is pinned
  if (p.GetPinCount() > 0) {
    return false;
  }

  // update replacer
  this->replacer_->Remove(frame_id);

  // update manager
  this->page_table_.erase(page_id);
  this->free_list_.emplace_back(frame_id);

  // reset page meta data
  p.ResetMemory();
  p.page_id_ = INVALID_PAGE_ID;
  p.pin_count_ = 0;
  p.is_dirty_ = false;

  // free page on disk
  DeallocatePage(page_id);
  return true;
}

auto BufferPoolManager::AllocatePage() -> page_id_t {
  // std::scoped_lock<std::mutex> guard(this->latch_);
  return next_page_id_++;
}

auto BufferPoolManager::FetchPageBasic(page_id_t page_id) -> BasicPageGuard {
  auto p = this->FetchPage(page_id);
  while (p == nullptr) {
    p = this->FetchPage(page_id);
  }
  return {this, p};
}

auto BufferPoolManager::FetchPageRead(page_id_t page_id) -> ReadPageGuard {
  auto p = this->FetchPage(page_id);
  while (p == nullptr) {
    p = this->FetchPage(page_id);
  }
  p->RLatch();
  return {this, p};
}

auto BufferPoolManager::FetchPageWrite(page_id_t page_id) -> WritePageGuard {
  auto p = this->FetchPage(page_id);
  while (p == nullptr) {
    p = this->FetchPage(page_id);
  }
  p->WLatch();
  return {this, p};
}

auto BufferPoolManager::NewPageGuarded(page_id_t *page_id) -> BasicPageGuard {
  auto p = this->NewPage(page_id);
  while (p == nullptr) {
    p = this->NewPage(page_id);
  }
  return {this, p};
}

}  // namespace bustub
